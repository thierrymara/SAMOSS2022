#Demo of the Bayesian Sparse PCE approach for Global Sensitivity Analysis
rm(list=ls())
library("randtoolbox")
source(paste0(getwd(),"/Benchmarks/GSABenchmarks.R"))
source(paste0(getwd(),"/BSPCE/BuildBSPCE_MAP.R"))
require(ggplot2)
SobolCoeff <- c(99,0,9,0,99,4.5,1,0,99,99,99,99,99,99,99,99,99,99,99,99,99)
Nvar <- length(SobolCoeff)
PCEType <- vector()
for(p in seq(1:Nvar)){
  PCEType <- c(PCEType,"Legendre")
}
## Randomized Sobol sequence (with digital shift)
#set.seed(271)
from <- 9
till <- 1
for(it in seq(1:till)){
  Nsample <- 2^(from+it)
  u <- sobol(Nsample,Nvar)#up to 360 - Lecuyer & Lemieux
  U <- 2*u - 1# U in [-1,1] for Legendre PCE
  X <- u# Variable transformation
  Response <- SobolFunction(X,SobolCoeff)
  PCE <- Build_SPCE(X,Response$y)#
  print("Unexplained amount of variance")
  print(PCE$Res)
  SA <- Compute_SI(PCE,X)#PCEType
  # #Display Si & STi
  Epsilon=0.02
  Abscisse <- seq(1:Nvar)
  plot(Abscisse,SA$Si[,2], col = "red", pch=20, 
       xlab = "Input Number", ylab="Sobol' Indices",
       xlim=c(1,Nvar),ylim=c(min(SA$Si[,1]),(1+0.2)*max(SA$STi[,3])),xaxt="n")
  axis(1,c(1:Nvar))
  segments(Abscisse,SA$Si[,1],Abscisse,SA$Si[,3], col = "red")
  segments(Abscisse-Epsilon,SA$Si[,1],Abscisse+Epsilon,SA$Si[,1], col = "red")
  segments(Abscisse-Epsilon,SA$Si[,3],Abscisse+Epsilon,SA$Si[,3], col = "red")
  points(Abscisse,SA$STi[,2], col = "blue", pch=21)
  segments(Abscisse,SA$STi[,1],Abscisse,SA$STi[,3])
  segments(Abscisse-Epsilon,SA$STi[,1],Abscisse+Epsilon,SA$STi[,1])
  segments(Abscisse-Epsilon,SA$STi[,3],Abscisse+Epsilon,SA$STi[,3])
  legend("topright",c("First-Order","Total-Order"), col=c("red","blue"),pch=c(20,21))
}
#The overall Indices
AllIndices      <- SA
AllIndices[1:6] <- NULL
print("The overall estimated Sobol' indices")
print(unlist(AllIndices))
