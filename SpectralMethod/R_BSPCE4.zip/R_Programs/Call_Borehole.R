rm(list=ls())
library("randtoolbox")
library("MASS")
source(paste0(getwd(),"/Benchmarks/borehole.R"))
source(paste0(getwd(),"/BSPCE/BuildBSPCE_MAP.R"))

require(ggplot2)
Nvar <- 8
PCEType <- vector()
for(p in seq(1:Nvar)){
  PCEType <- c(PCEType,"Uniform")
}
PDF<-list()
PDF$Coeff <- matrix()
PDF$Coeff <- matrix(c(0.10 ,7.71,63070 ,6.95  ,63 ,6.6  ,1120,9855,
                      0.016,1   ,100000,0.0167,116,0.033,1680,12045,
                      0.0  ,0.0 ,115600,0.0   ,0.0,0.0  ,0.0 ,0.0),
                    ncol=3,
                    nrow=Nvar)
PDF$Type <- vector()
PDF$Type <- c('Normal','LogNormal','Triangular','LogNormal','Uniform','LogNormal','Uniform','Uniform')
## Randomized Sobol sequence (with digital shift)
#set.seed(271]
Nsample <- 2^7
U <- sobol(Nsample,Nvar)

X <- matrix(0,Nsample,Nvar)
#Transformation
X[,1] <- qnorm(U[,1])*PDF$Coeff[1,2]+PDF$Coeff[1,1]#Normal
#
X[,2] <- exp(qnorm(U[,2])*PDF$Coeff[2,2]+PDF$Coeff[2,1])#LogNormal
#
Ind1 <- which(U[,3]<(PDF$Coeff[3,2]-PDF$Coeff[3,1])/(PDF$Coeff[3,3]-PDF$Coeff[3,1]))
Ind2 <- which(U[,3]>=(PDF$Coeff[3,2]-PDF$Coeff[3,1])/(PDF$Coeff[3,3]-PDF$Coeff[3,1]))
X[Ind1,3]=PDF$Coeff[3,1]+sqrt(U[Ind1,3]*(PDF$Coeff[3,2]-PDF$Coeff[3,1])*(PDF$Coeff[3,3]-PDF$Coeff[3,1]))
X[Ind2,3]=PDF$Coeff[3,3]-sqrt((PDF$Coeff[3,3]-PDF$Coeff[3,2])*(1-U[Ind2,3])*(PDF$Coeff[3,3]-PDF$Coeff[3,1]))#Triangle
#
X[,4] <- exp(qnorm(U[,4])*PDF$Coeff[4,2]+PDF$Coeff[4,1])#LogNormal
#
X[,5] <- U[,5]*(PDF$Coeff[5,2]-PDF$Coeff[5,1])+PDF$Coeff[5,1]#Uniform
#
X[,6] <- exp(qnorm(U[,6])*PDF$Coeff[6,2]+PDF$Coeff[6,1])#LogNormal
#
X[,7] <- U[,7]*(PDF$Coeff[7,2]-PDF$Coeff[7,1])+PDF$Coeff[7,1]#Uniform
#
X[,8] <- U[,8]*(PDF$Coeff[8,2]-PDF$Coeff[8,1])+PDF$Coeff[8,1]#Uniform

#Model Call
y<-vector()
for(k in seq(from=1,to=Nsample)){
  y[k] <- borehole(X[k,])
}
#PCE Building
PCE <- Build_SPCE(X,y)#
#Sensitivity Indices Estimate
SA <- Compute_SI(PCE,X)#
AllIndices      <- SA
AllIndices[1:6] <- NULL

Epsilon=0.00
Abscisse <- seq(1:Nvar)
plot(Abscisse,SA$Si[,2], col = "red", pch=20, 
     xlab = "Input Number", ylab="Sobol' Indices",
     xlim=c(1,Nvar),ylim=c(min(SA$Si[,1]),(1+0.2)*max(SA$STi[,3])),xaxt="n")
axis(1,c(1:Nvar))
segments(Abscisse,SA$Si[,1],Abscisse,SA$Si[,3], col = "red")
segments(Abscisse-Epsilon,SA$Si[,1],Abscisse+Epsilon,SA$Si[,1], col = "red")
segments(Abscisse-Epsilon,SA$Si[,3],Abscisse+Epsilon,SA$Si[,3], col = "red")
points(Abscisse,SA$STi[,2], col = "blue", pch=21)
segments(Abscisse,SA$STi[,1],Abscisse,SA$STi[,3])
segments(Abscisse-Epsilon,SA$STi[,1],Abscisse+Epsilon,SA$STi[,1])
segments(Abscisse-Epsilon,SA$STi[,3],Abscisse+Epsilon,SA$STi[,3])
legend("topright",c("First-Order","Total-Order"), col=c("red","blue"),pch=c(20,21))

print("Unexplained amount of variance")
print(PCE$Res)
#The overall Indices
print("The overall estimated Sobol' indices")
print(unlist(AllIndices))
