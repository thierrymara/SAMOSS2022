#A Series of Benchmark Functions for testing Numerical Methods for Global Sensitivity Analysis
SobolFunction<-function(Sample,Coeff)
{
  N  <- nrow(Sample)
  p1 <- ncol(Sample)
  p  <- length(Coeff)
  
  if(p==p1){
    
  }
  else{
    print("Error!The number of columns should be equal to the number of coefficients!");
  return()
  }
  
  # For the first-order sensitivity indices
  Beta <- ((1 + Coeff)^(-2))/3
  D    <- prod((1 + Beta)) - 1
  Si   <- Beta
  
  cmpt <- 0
  cnt  <- 0
  Sij  <- vector()
  Sijk <- vector()
  STij <- vector()
  for(k in seq(1:length(Si))){
    for(kk in seq(from=k+1,to=length(Si))){
      cnt <- cnt+1
      Sij <- c(Sij,Si[k]*Si[kk])
      STij1    <- c(Si[k],Si[kk],Si[k]*Si[kk])
      for(kkk in seq(1:min(p,10))){
        if((kkk!=k)&(kkk!=kk)){
          cmpt  <- cmpt+1
          STij1 <- c(STij1,STij1*Si[kkk])
          Sijk <- c(Sijk,Si[k]*Si[kk]*Si[kkk])
        }
      }
      STij <- c(STij,sum(STij1))
    }
  }
  
  # For the total sensitivity indices
  STi <- vector()
  for(i in seq(1:p)){
    STi[i] <- Si[i];
    ST1    <- Si[i];
    for(j in seq(1:min(p,10))){
      if(i!=j){
        ST1 <- c(ST1,ST1*Si[j])
      }
    }
    STi[i] <- sum(ST1)
  }
  
  # The first-order and total sensitivity indices are resp.
  Si  <- Si/D
  STi <- STi/D
  
  # Evaluation fo the Sobol' Function
  Y  <- matrix(0,N,1)
  DY <- matrix(0,N,p)
  for(i in seq(1:N)){
    Y[i,1] <- 1
    DY[i,1:p] <- matrix(1,1,p)
    for(j in seq(1:p)){
      Output <- gfunction(Sample[i,j],Coeff[j])
      Y[i,1] <- Y[i,1]*Output$Y
      for(jj in seq(1:p)){
        if(j==jj){
          DY[i,jj] <- DY[i,jj]*Output$dY
        }
        else{
          DY[i,jj] <- DY[i,jj]*Output$Y
        }
      }
    }
  }
  
  return(list("y"=Y,"Si"=Si,"STi"=STi,"Dy"=DY))
}
gfunction<-function(x,a)
{
  y  <- (abs(4*x-2)+a)/(1+a)
  dy <- 4*sign(4*x-2)/(1+a)
  return(list("Y"=y,"dY"=dy))
}
#------------------- The Ishigami Function (3 variables) --------------------
IshigamiFunction<-function(X,A)
{
  Nsample  <- nrow(X)
  Nvar <- ncol(X)
  p <- length(A)
  if(p!=2){
    print("Error!The number of coefficients should be equal to 2!")
  return()
  }
  if(Nvar<3){
    print("Error!The number of variables should be at least equal to 3!")
    return()
  }
  # First-order sensitivity indices
  D    <- (A[1]^2)/8 + (A[2]*pi^4)/5 + (A[2]^2*pi^8)/18 + 0.5
  D1   <- (A[2]*pi^4)/5 + (A[2]^2*pi^8)/50 + 0.5
  D2   <- (A[1]^2)/8;
  D3   <- D12 <- D23 <- D123 <- 0
  D13  <- 8*A[2]^2*pi^8/225
  
  Si  <- matrix(0,1,Nvar)
  STi <- matrix(0,1,Nvar)
  Si  <- c(D1/D,D2/D,D3/D)
  STi <- c((D1+D13)/D,(D2)/D,(D3+D13)/D)
  
  # Evaluation of the Ishigami function
  Y  <- matrix(0,Nsample,1)
  DY <- matrix(0,Nsample,3)
  Y[,1]  <- sin(X[,1]) + A[1]*(sin(X[,2])^2)+A[2]*(X[,3]^4)*sin(X[,1])
  DY[,1] <- cos(X[,1])+A[2]*(X[,3]^4)*cos(X[,1])
  DY[,2] <- 2*A[1]*(sin(X[,2])*cos(X[,2]))
  DY[,3] <- 4*A[2]*(X[,3]^3)*sin(X[,1])
  
  return(list("y"=Y,"Si"=Si,"STi"=STi,"Dy"=DY))
}
#---------------- The Morris function (20 variables) --------------
MorrisFunction<-function(Sample)
{
  Nsample  <- nrow(Sample)
  Nvar <- min(20,ncol(Sample))
  
  Coeff <- read.csv(file="MorrisCoeff.csv",header=FALSE,sep=",")
  
  Y   <- matrix(0,Nsample,1)
  cnt <- 0
  X   <- matrix(0,Nsample,Nvar)
  for(p in seq(1:Nvar)){
    if((p==3)|(p==5)|(p==7)){
      X[,p] <- 2*(1.1*Sample[,p]/(Sample[,p]+0.1)-0.5)
    }
    else{
      X[,p] <- 2*(Sample[,p]-0.5)
    }
    
    cnt <- cnt+1
    Y   <- Y + Coeff[1,cnt]*X[,p]
  }
  
  for(p in seq(1:(Nvar-1))){
    for(pp in seq(from=p+1,to=Nvar)){
      cnt <- cnt+1
      Y <-  Y + Coeff[1,cnt]*X[,p]*X[,pp]
    }
  }

  for(p in seq(1:(Nvar-2))){
    for(pp in seq(from=p+1, to=(Nvar-1))){
      for(ppp in seq(from=pp+1,to=Nvar)){
        cnt <- cnt+1
        Y <- Y + Coeff[1,cnt]*X[,p]*X[,pp]*X[,ppp]
      }
    }
  }

  for(p in seq(1:(Nvar-3))){
    for(pp in seq(from=p+1, to=(Nvar-2))){
      for(ppp in seq(from=pp+1,to=(Nvar-1))){
        for(pppp in seq(from=ppp+1,to=Nvar)){
          cnt <- cnt+1
          Y <- Y + Coeff[1,cnt]*X[,p]*X[,pp]*X[,ppp]*X[,pppp]
        }
      }
    }
  }
  return(list("y"=Y))
}