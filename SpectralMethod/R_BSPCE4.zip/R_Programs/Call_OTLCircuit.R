rm(list=ls())
library("randtoolbox")
source(paste0(getwd(),"/Benchmarks/otlcircuit.R"))
source(paste0(getwd(),"/BSPCE/BuildBSPCE_MAP.R"))

require(ggplot2)


Nvar <- 6
PDF<-list()
PDF$Coeff <- matrix()
PDF$Coeff <- matrix(c(100 , 25 , 3  ,0.18, -0.58,50 ,
                      33/2, 70 , 3,0.92, 0.27 ,100,
                      0.0 , 0.0, 0.5,0.0 , 0.0  ,300),
                    ncol=3,
                    nrow=Nvar)
PDF$Type <- vector()
PDF$Type <- c('Normal','Uniform','Gamma','LogUniform','LogNormal','Triangular')
## Randomized Sobol sequence (with digital shift)
#set.seed(271]
Nsample <- 2^7
U <- sobol(Nsample,Nvar)

X <- matrix(0,Nsample,Nvar)
#Transformation
X[,1] <- qnorm(U[,1])*PDF$Coeff[1,2]+PDF$Coeff[1,1]#Normal
#
X[,2] <- U[,2]*(PDF$Coeff[2,2]-PDF$Coeff[2,1])+PDF$Coeff[2,1]#Uniform
#
X[,3] <- PDF$Coeff[3,3]+qgamma(U[,3],PDF$Coeff[3,1],PDF$Coeff[3,2])#Gamma
#
X[,4] <- exp(U[,4]*(PDF$Coeff[4,2]-PDF$Coeff[4,1])+PDF$Coeff[4,1])#LogUniform
#
X[,5] <- exp(qnorm(U[,5])*PDF$Coeff[5,2]+PDF$Coeff[5,1])#LogNormal
#
Ind1 <- which(U[,6]<(PDF$Coeff[6,2]-PDF$Coeff[6,1])/(PDF$Coeff[6,3]-PDF$Coeff[6,1]))
Ind2 <- which(U[,6]>=(PDF$Coeff[6,2]-PDF$Coeff[6,1])/(PDF$Coeff[6,3]-PDF$Coeff[6,1]))
X[Ind1,6] <- PDF$Coeff[6,1]+sqrt(U[Ind1,6]*(PDF$Coeff[6,2]-PDF$Coeff[6,1])*(PDF$Coeff[6,3]-PDF$Coeff[6,1]))
X[Ind2,6] <- PDF$Coeff[6,3]-sqrt((PDF$Coeff[6,3]-PDF$Coeff[6,2])*(1-U[Ind2,6])*(PDF$Coeff[6,3]-PDF$Coeff[6,1]))#Triangle

#Model Call
y<-vector()
for(k in seq(from=1,to=Nsample)){
  y[k] <- otlcircuit(X[k,])
}
#PCE Building
PCE <- Build_SPCE(X,y)#
#Sensitivity Indices Estimate
SA <- Compute_SI(PCE,X)#
AllIndices      <- SA
AllIndices[1:6] <- NULL

Epsilon=0.00
Abscisse <- seq(1:Nvar)
plot(Abscisse,SA$Si[,2], col = "red", pch=20, 
     xlab = "Input Number", ylab="Sobol' Indices",
     xlim=c(1,Nvar),ylim=c(min(SA$Si[,1]),(1+0.2)*max(SA$STi[,3])),xaxt="n")
axis(1,c(1:Nvar))
segments(Abscisse,SA$Si[,1],Abscisse,SA$Si[,3], col = "red")
segments(Abscisse-Epsilon,SA$Si[,1],Abscisse+Epsilon,SA$Si[,1], col = "red")
segments(Abscisse-Epsilon,SA$Si[,3],Abscisse+Epsilon,SA$Si[,3], col = "red")
points(Abscisse,SA$STi[,2], col = "blue", pch=21)
segments(Abscisse,SA$STi[,1],Abscisse,SA$STi[,3])
segments(Abscisse-Epsilon,SA$STi[,1],Abscisse+Epsilon,SA$STi[,1])
segments(Abscisse-Epsilon,SA$STi[,3],Abscisse+Epsilon,SA$STi[,3])
legend("topright",c("First-Order","Total-Order"), col=c("red","blue"),pch=c(20,21))

print("Unexplained amount of variance")
print(PCE$Res)
#The overall Indices
print("The overall estimated Sobol' indices")
print(unlist(AllIndices))
