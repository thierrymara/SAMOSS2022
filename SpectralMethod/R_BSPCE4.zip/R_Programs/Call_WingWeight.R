rm(list=ls())
library("randtoolbox")
source(paste0(getwd(),"/Benchmarks/wingweight.R"))
source(paste0(getwd(),"/BSPCE/BuildBSPCE_MAP.R"))

require(ggplot2)


Nvar <- 10
PDF<-list()
PDF$Coeff <- matrix()
PDF$Coeff <- matrix(c(150 ,220 ,6  ,0.0,2.0 ,-0.7,0.08,4.25,1700,0.025,
                      200 ,300 ,10 ,2.0,1/3.0 ,0.0 ,0.18,0.6 ,2000,20.0 ,
                      0.0 ,0.0 ,0.0,0.0,16.0,0.0 ,0.0 ,0.0 ,2500,0.08),
                    ncol=3,
                    nrow=Nvar)
PDF$Type <- vector()
PDF$Type <- c('Uniform','Uniform','Discrete','Laplace','Gamma','LogUniform','Uniform','Normal','Triangular','Exponential')
## Randomized Sobol sequence (with digital shift)
#set.seed(271]
Nsample <- 2^7
U <- sobol(Nsample,Nvar)

X <- matrix(0,Nsample,Nvar)
#Transformation
X[,1] <- U[,1]*(PDF$Coeff[1,2]-PDF$Coeff[1,1])+PDF$Coeff[1,1]#Uniform
#
X[,2] <- U[,2]*(PDF$Coeff[2,2]-PDF$Coeff[2,1])+PDF$Coeff[2,1]#Uniform
#
X[,3] <- floor(U[,3]*(PDF$Coeff[3,2]-PDF$Coeff[3,1]+1))+PDF$Coeff[3,1]#Discrete Uniform
#
Ind1 <- which(U[,4]<0.5)
Ind2 <- which(U[,4]>=0.5)
X[Ind1,4] <- PDF$Coeff[4,1]+PDF$Coeff[4,2]*log(2*U[Ind1,4])
X[Ind2,4] <- PDF$Coeff[4,1]-PDF$Coeff[4,2]*log(2*(1-U[Ind2,4]))#Laplace
#
X[,5] <- PDF$Coeff[5,3]+qgamma(U[,5],PDF$Coeff[5,1],PDF$Coeff[5,2])#Gamma
#
X[,6] <- exp(U[,6]*(PDF$Coeff[6,2]-PDF$Coeff[6,1])+PDF$Coeff[6,1])#LogUniform
#
X[,7] <- U[,7]*(PDF$Coeff[7,2]-PDF$Coeff[7,1])+PDF$Coeff[7,1]#Uniform
#
X[,8] <- qnorm(U[,8])*PDF$Coeff[8,2]+PDF$Coeff[8,1]#Normal
#
Ind1 <- which(U[,9]<(PDF$Coeff[9,2]-PDF$Coeff[9,1])/(PDF$Coeff[9,3]-PDF$Coeff[9,1]))
Ind2 <- which(U[,9]>=(PDF$Coeff[9,2]-PDF$Coeff[9,1])/(PDF$Coeff[9,3]-PDF$Coeff[9,1]))
X[Ind1,9] <- PDF$Coeff[9,1]+sqrt(U[Ind1,9]*(PDF$Coeff[9,2]-PDF$Coeff[9,1])*(PDF$Coeff[9,3]-PDF$Coeff[9,1]))
X[Ind2,9] <- PDF$Coeff[9,3]-sqrt((PDF$Coeff[9,3]-PDF$Coeff[9,2])*(1-U[Ind2,9])*(PDF$Coeff[9,3]-PDF$Coeff[9,1]))#Triangle
#
X[,10] <- -log(exp(-PDF$Coeff[10,2]*PDF$Coeff[10,1])-U[,10]*(exp(-PDF$Coeff[10,2]*PDF$Coeff[10,1])-exp(-PDF$Coeff[10,2]*PDF$Coeff[10,3])))/PDF$Coeff[10,2]#Exponential

#Model Call
y<-vector()
for(k in seq(from=1,to=Nsample)){
  y[k] <- wingweight(X[k,])
}
#PCE Building
X[,3] <- U[,3]
PCE <- Build_SPCE(X,y)#
#Sensitivity indices Estimate
SA <- Compute_SI(PCE,X)#
AllIndices      <- SA
AllIndices[1:6] <- NULL

Epsilon=0.00
Abscisse <- seq(1:Nvar)
plot(Abscisse,SA$Si[,2], col = "red", pch=20, 
     xlab = "Input Number", ylab="Sobol' Indices",
     xlim=c(1,Nvar),ylim=c(min(SA$Si[,1]),(1+0.2)*max(SA$STi[,3])),xaxt="n")
axis(1,c(1:Nvar))
segments(Abscisse,SA$Si[,1],Abscisse,SA$Si[,3], col = "red")
segments(Abscisse-Epsilon,SA$Si[,1],Abscisse+Epsilon,SA$Si[,1], col = "red")
segments(Abscisse-Epsilon,SA$Si[,3],Abscisse+Epsilon,SA$Si[,3], col = "red")
points(Abscisse,SA$STi[,2], col = "blue", pch=21)
segments(Abscisse,SA$STi[,1],Abscisse,SA$STi[,3])
segments(Abscisse-Epsilon,SA$STi[,1],Abscisse+Epsilon,SA$STi[,1])
segments(Abscisse-Epsilon,SA$STi[,3],Abscisse+Epsilon,SA$STi[,3])
legend("topright",c("First-Order","Total-Order"), col=c("red","blue"),pch=c(20,21))

print("Unexplained amount of variance")
print(PCE$Res)
#The overall Indices
print("The overall estimated Sobol' indices")
print(unlist(AllIndices))