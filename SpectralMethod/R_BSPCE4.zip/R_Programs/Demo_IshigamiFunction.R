#Demo of the Bayesian Sparse PCE approach for Global Sensitivity Analysis
rm(list=ls())
library("randtoolbox")
source(paste0(getwd(),"/Benchmarks/GSABenchmarks.R"))
source(paste0(getwd(),"/BSPCE/BuildBSPCE_MAP.R"))
require(ggplot2)
Nvar <- 3
IshigamiCoeff <- c(7,0.1)
PCEType <- vector()
for(p in seq(1:Nvar)){
  PCEType <- c(PCEType,"Legendre")
}
## Randomized Sobol sequence (with digital shift)
#set.seed(271)
from <- 4
till <- 8
for(it in seq(1:till)){
  Nsample <- 2^(from+it)
  u <- sobol(Nsample,Nvar)#up to 360 - Lecuyer & Lemieux
  U <- 2*u - 1# U in [-1,1] for Legendre PCE
  X <- U*pi# Variable transformation
  Response <- IshigamiFunction(X,IshigamiCoeff)
  PCE <- Build_SPCE(X,Response$y)#
  print("Unexplained amount of variance")
  print(PCE$Res)
  SA <- Compute_SI(PCE,X)#
  
  if(it==1){
    ytop <- 0
    plot(from+it, log(sum(abs(Response$Si-SA$Si[,2]))),
         pch=20, xlab="log2(N)", ylab="Error S_i/ST_I",
         main="Ishigami Function",xlim=c(from+1,from+till+1),ylim=(c(-18,ytop)))
    points(from+it, log(sum(abs(Response$STi-SA$STi[,2]))),
           pch=21, col="red")
    legend("topright",legend=c("S_i","ST_i"),
           col=c("black", "red"), pch=c(20,21), cex=0.8)
  }
  else{
    points(from+it, log(sum(abs(Response$Si-SA$Si[,2]))),
           pch=20)
    points(from+it, log(sum(abs(Response$STi-SA$STi[,2]))),
           pch=21, col="red")
  }
}
#The overall Indices
AllIndices      <- SA
AllIndices[1:6] <- NULL
print("The overall estimated Sobol' indices")
print(unlist(AllIndices))
