rm(list=ls())
library(randtoolbox)
library(MASS)
source(paste0(getwd(),"/Benchmarks/moonetal12.R"))
source(paste0(getwd(),"/BSPCE/BuildBSPCE_MAP.R"))

require(ggplot2)


Nvar <- 31
PDF<-list()
PCEType <- vector()
PDF$Type <- vector()
for(p in seq(1:Nvar)){
  PDF$Type <- c(PDF$Type,"Uniform")
}

PDF$Coeff <- matrix()
PDF$Coeff <- matrix(c(0.100,7.71,63070 ,990 ,63.1,700,1120,9855 ,150,220,6 ,0,16,0.5,0.08,2.50,1700,0.025,50 ,25,0.5,1.2,0.25,50 ,30,0.005,0.002,1000,90000 ,290,340,
                      0.016,1.00,115600,1110,116 ,800,1680,12045,200,300,10,2,45,1.0,0.18,6.00,2500,0.080,150,70,3.0,2.5,1.20,300,60,0.020,0.010,5000,110000,296,360),
                    ncol=2,
                    nrow=Nvar)

PDF$Type[1] <- 'Normal'
PDF$Type[2] <- 'LogNormal'
PDF$Type[12] <- 'Laplace'
## Randomized Sobol sequence (with digital shift)
#set.seed(271]
Nsample <- 2^7
U <- sobol(Nsample,Nvar)

X <- matrix(0,Nsample,Nvar)
#
X[,1] <- qnorm(U[,1])*PDF$Coeff[1,2]+PDF$Coeff[1,1]#Normal
#
X[,2] <- exp(qnorm(U[,2])*PDF$Coeff[2,2]+PDF$Coeff[2,1])#LogNormal
#
for(p in 3:Nvar){
  X[,p] <- U[,p]*(PDF$Coeff[p,2]-PDF$Coeff[p,1])+PDF$Coeff[p,1]#Uniform
}
#
Ind1 <- which(U[,12]<0.5)
Ind2 <- which(U[,12]>=0.5)
X[Ind1,12] <- PDF$Coeff[12,1]+PDF$Coeff[12,2]*log(2*U[Ind1,12])
X[Ind2,12] <- PDF$Coeff[12,1]-PDF$Coeff[12,2]*log(2*(1-U[Ind2,12]))#Laplace
#
#Model Call
y<-vector()
for(k in seq(from=1,to=Nsample)){
  y[k] <- moonetal12(X[k,])
}
#PCE Building
PCE <- Build_SPCE(X,y)#
#Sensitivity indices Estimate
SA <- Compute_SI(PCE,X)#
AllIndices      <- SA
AllIndices[1:6] <- NULL

Epsilon=0.00
Abscisse <- seq(1:Nvar)
plot(Abscisse,SA$Si[,2], col = "red", pch=20, 
     xlab = "Input Number", ylab="Sobol' Indices",
     xlim=c(1,Nvar),ylim=c(min(SA$Si[,1]),(1+0.2)*max(SA$STi[,3])),xaxt="n")
axis(1,c(1:Nvar))
segments(Abscisse,SA$Si[,1],Abscisse,SA$Si[,3], col = "red")
segments(Abscisse-Epsilon,SA$Si[,1],Abscisse+Epsilon,SA$Si[,1], col = "red")
segments(Abscisse-Epsilon,SA$Si[,3],Abscisse+Epsilon,SA$Si[,3], col = "red")
points(Abscisse,SA$STi[,2], col = "blue", pch=21)
segments(Abscisse,SA$STi[,1],Abscisse,SA$STi[,3])
segments(Abscisse-Epsilon,SA$STi[,1],Abscisse+Epsilon,SA$STi[,1])
segments(Abscisse-Epsilon,SA$STi[,3],Abscisse+Epsilon,SA$STi[,3])
legend("topright",c("First-Order","Total-Order"), col=c("red","blue"),pch=c(20,21))

print("Unexplained amount of variance")
print(PCE$Res)
#The overall Indices
print("The overall estimated Sobol' indices")
print(unlist(AllIndices))
