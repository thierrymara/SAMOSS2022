#Response = BSPCE(X,y)
#Compute the variance-based sensitivity indices (Sobol' indices) with the Bayesian
#Sparse Polynomial Chaos Expansion (BSPCE) introduced in 
#Shao Q., Younes A., Fahs M. and Mara T.A. (2017),Comput. Methods in Appl. Mech. & Engrg. (318) 474-496.
#with the difference that, from given data, PC bases are built with the Gram-Schmidt method.
#Note that Gram-Schmidt based orthogonal bases might perform poorly in some cases.
#Input: X a Monte Carlo sample of size NsamplexNvar, 
#       y the associated model response vector assumed a continuous random variable
#Output: Response$SI contains information related to the Sobol' indices
#        Response$PCE contains information related to the BSPCE
Build_SPCE<-function(X,y)
{
  Nsample  <- nrow(X)
  Nvar     <- ncol(X)
  Degree_Init <- 4
  Level_Init <- 2
  if(Nvar>20){
    Degree_Init <- 2
    Level_Init <- 1 
  }
  X_std<-X
  if(nargs()<3){
    X_std <- matrix(0,Nsample,Nvar)
    for(p in seq(1:Nvar)){
      X_std[,p] <- (X[,p]-mean(X[,p]))/sd(X[,p])
    }
  }
  PCE <- Compute_SPCE(X_std,y,Degree_Init,Level_Init)
  return(PCE)
}
#------------------ Main_Efect Compute the correlatin ratio ----------
# [Response] = function(x,y,m)
# Evaluate the correlation ratio of x w.r.t. y by polynomial regression
# The maximal polynomial degree is m (by default m=1)
# Response is a structure array: Si (correlation ratio), Res (Residual)
Main_Effect<-function(X,y,m=1)
{
  if(is.null(dim(X))){
    Nsample  <- length(X)
    Nvar     <- 1
  }
  else{
  Nsample  <- nrow(X)
  Nvar     <- ncol(X)
  }
  y1 <- y
  Si <- vector()
  for(par in seq(1:Nvar)){
    if(Nvar>1){
      Entree <- X[,par]
    }
    else{
      Entree <- X
    }
    ModelPolynomial  <- lm(formula=y1 ~ poly(Entree,m,raw=TRUE))
    Sortie_calc <- predict(ModelPolynomial)
    Si[par] = var(Sortie_calc)/var(y)
    y1 <- y1 - Sortie_calc
  }
  
  return(list("Si"=Si,"Res"=y1))
}
###########################################################
#------------------ Compute the BSPCE ---------------------
###########################################################
Compute_SPCE<-function(X,y,p1=4,q1=2)
{
  if(is.null(dim(X))){
    print("X should be an array and not a vector")
    return()
  }
  Nsample  <- nrow(X)
  Nvar     <- ncol(X)
  Matdegree <- PCE_Structure(Nvar,p1,q1)#Create the Matrix of Polynomial Degrees
  #Filtering Discrete Variables
  Deg_Max<-vector()
  for(p in seq(1:Nvar)){
    Xr<-sort(X[,p],decreasing = FALSE)
    Deg_Max[p] <- +Inf
    if(sum((Xr[-1]-Xr[1:(Nsample-1)])==0)>Nsample/2){
      Deg_Max[p] <- sum((Xr[-1]-Xr[1:(Nsample-1)])!=0)+1
      Ind<-(Matdegree[,p]<=Deg_Max[p])
      Matdegree<-Matdegree[Ind,]
    }
  }
  
  NCoeff <- nrow(Matdegree)
  Display <- "On"
  if(Display=="On"){
    message(sprintf('The number of terms in the SPCE is: %i',nrow(Matdegree)))
  }
  
  PCE <- list()
  PCE$Mat   <- Matdegree#Only usefull for passing the first test (while)
  Matdegree  <- rbind(Matdegree,Matdegree[-(1:(NCoeff-1)),])#Only usefull for passing the first test (while)
  Degree_max <- p1#Initial max PCE degree
  Level_max <- q1 #Initial max PCE level of interactions
  ##----------------------------------------------------------------------##
  ############## SERIOUS THINGS START HERE #################################
  ##----------------------------------------------------------------------##
  PCE$Message <- NULL
  while(nrow(Matdegree)!=nrow(PCE$Mat)){#Stopping criterion
    if(Display=="On"){
      message(sprintf("Polynomial Degree:  %i\t Interaction Level:  %i", Degree_max,Level_max))
    }
    Step <- -1
    while(nrow(PCE$Mat)!=nrow(Matdegree)){
      Matdegree <- PCE$Mat
      PCE <- Filter_Matrix_PCE(X,y,Matdegree,Step)
      #print(PCE$Mat)
      #readline("Pause")
      Partial_Variance <- sort((PCE$Cr[-1])^2, method = "quick", decreasing = TRUE, index.return = TRUE)
      PCE$Mat <- rbind(PCE$Mat[1,],PCE$Mat[(Partial_Variance$ix+1),])
      Step <- 1
    }
    
    Index <- which(rowSums(PCE$Mat)>=(Degree_max-1))
    if(length(Index)!=0){
      Degree_max <- Degree_max+2 #Increase the maximal degree of PCE
      for(j in seq(1:length(Index))){
        Ind <- which(PCE$Mat[Index[j],]>0)
        for(jj in seq(1:length(Ind))){
          Vect1 <- PCE$Mat[Index[j],]
          Vect1[Ind[jj]] <- Vect1[Ind[jj]]+2
          Test <- 1
          for(tt in seq(1:nrow(PCE$Mat))){
            if(sum(abs(PCE$Mat[tt,]-Vect1))==0){
              Test <- -1
              break
            }
          }
          if(Test==1){
          PCE$Mat <- rbind(PCE$Mat,PCE$Mat[Index[j],])
          Fin <- nrow(PCE$Mat)
          PCE$Mat[Fin,Ind[jj]] <- PCE$Mat[Fin,Ind[jj]]+2
          }
        }
      }
    }
    
    for(p in seq(1:Nvar)){
        Ind<-(PCE$Mat[,p]<=Deg_Max[p])
        PCE$Mat<-PCE$Mat[Ind,]
      }
    
    Mat <- replace(PCE$Mat,which(PCE$Mat==0),1)
    MatOne <- PCE$Mat/Mat
    Param <- which(colSums(MatOne)>0)#Relevant Inputs
    Indix <- which(rowSums(MatOne)==Level_max)#Is the Level interactions = current max level?
    if(length(Indix)!=0){
      Level_max <- Level_max+1 #Increase the maximal level of interactions
      for(j in seq(1:length(Indix))){
        Indux<- which(PCE$Mat[Indix[j],Param]==0)
        d <- Degree_max-sum(PCE$Mat[Indix[j],])
        for(jj in seq(1:d)){
          for(jjj in seq(1:length(Indux))){
            Vect <- PCE$Mat[Indix[j],]
            Vect[Param[Indux[jjj]]] <- jj
            Test <- 1
            for(tt in seq(1:nrow(PCE$Mat))){
              if(sum(abs(PCE$Mat[tt,]-Vect))==0){
                Test <- -1
                break
              }
            }
            if(Test==1){
              PCE$Mat <- rbind(PCE$Mat,PCE$Mat[Indix[j],])
              Fin <- nrow(PCE$Mat)
              PCE$Mat[Fin,Param[Indux[jjj]]] <- jj
            }
          }
        }
      }
    }
  }
  return(PCE)
}
###########################################################
#------------------ Filter_Matrix_PCE ---------------------
###########################################################
Filter_Matrix_PCE<-function(Fact,Sortie,Matdegree,Step=-1)
{
  Nsample  <- nrow(Fact)
  Nvar     <- ncol(Fact)
  Matdegree1 <- Matdegree
  Degree_max <- max(rowSums(Matdegree))
  Alpha1 <- matrix(0,Degree_max,Nvar)

  MatriceCoeff <- list()
  for(p in seq(1:Nvar)){
    MatriceCoeff[[paste('Inp',p)]] <- matrix()
    MatriceCoeff[[paste('Inp',p)]] <- CoefficientPolynomeqqc_GramSchmidt(Fact[,p],Degree_max)
    for(d in seq(1:Degree_max)){
      Alpha1[d,p] <- 1
    }
  }
  #%%%%%%%%%%%%%%%%%%%%%%%%%%%% STEP 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  y <- Sortie
  if(Step<=0){
    Variance <- matrix(0,nrow(Matdegree),1)
    for(r in seq(from=2,to=nrow(Matdegree))){
      Matrice <- matrix(1,length(Sortie),1)
      Ind <- which(Matdegree[r,]>0)
      if(length(Ind)!=0){
        for(n in seq(1:length(Ind))){
          Mat_puiss <- matrix(0,Nsample,(Matdegree[r,Ind[n]]+1))
          for(p in seq(1:(Matdegree[r,Ind[n]]+1))){
            Mat_puiss[,p] <- Fact[,Ind[n]]^(p-1)
          }
          Vecteur <- Mat_puiss%*%MatriceCoeff[[paste('Inp',Ind[n])]][(Matdegree[r,Ind[n]]+1),1:(Matdegree[r,Ind[n]]+1)]
          Matrice <- Matrice*Vecteur
        }
      }
      else{
        print("Error somewhere! Please check Matdegree")
        return()
      }
      PearsonCC <- cor(Matrice,y)
      Variance[r] <- PearsonCC^2
    }
    
    Matdegree1 <- Matdegree
    #Rank the PC terms by order of importance w.r.t. PearsonCC
    Resultat <- sort((Variance[-1])^2, method = "quick", decreasing = TRUE, index.return = TRUE)
    Indice <- c(1,(Resultat$ix+1))
    Matdegree <- Matdegree1[Indice,]
    #%%%%%%%%%%%%%%%%%%%%%%%%% STEP 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    y <- Sortie
    Variance <- matrix(0,nrow(Matdegree),1)
    for(r in seq(from=2,to=nrow(Matdegree))){
      Matrice <- matrix(1,length(Sortie),1)
      Ind <- which(Matdegree[r,]>0)
      if(length(Ind)!=0){
        for(n in seq(1:length(Ind))){
          Mat_puiss <- matrix(0,Nsample,(Matdegree[r,Ind[n]]+1))
          for(p in seq(1:(Matdegree[r,Ind[n]]+1))){
            Mat_puiss[,p] <- Fact[,Ind[n]]^(p-1)
          }
          Vecteur <- Mat_puiss%*%MatriceCoeff[[paste('Inp',Ind[n])]][(Matdegree[r,Ind[n]]+1),1:(Matdegree[r,Ind[n]]+1)]#(MatriceCoeff[-(1:Matdegree[r,Ind[n]]),1:(Matdegree[r,Ind[n]]+1)])
          Matrice <- Matrice*Vecteur/(sqrt(Alpha1[Matdegree[r,Ind[n]],Ind[n]]))
        }
      }
      else{
        print("Error somewhere! Please check Matdegree")
        return()
      }
      Ai=solve(t(cbind(matrix(1,Nsample,1),Matrice))%*%cbind(matrix(1,Nsample,1),Matrice),t(cbind(matrix(1,Nsample,1),Matrice))%*%y)
      y1 <- Ai[1]+Ai[2]*Matrice
      Variance[r,1] <- var(y1)/var(Sortie)
      y <- y - y1
    }
    Matdegree1 <- Matdegree
    #Rank the PC terms by order of importance w.r.t. PearsonCC
    Resultat <- sort((Variance[-1])^2, method = "quick", decreasing = TRUE, index.return = TRUE)
    Indice <- c(1,(Resultat$ix+1))
    Matdegree1 <- Matdegree1[Indice,]
  }
  #%%%%%%%%%%%%%%%%%%%%%%%%% STEP 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
  y_std <- (Sortie-mean(Sortie))/sd(Sortie)
  
  Sigma2P <- 1
  Matdegree <- Matdegree1[1,]
  Matrice <- matrix(1,Nsample,1)
  KIC_Prec <- Inf
  puiss <- 2.0
  for(r in seq(from=2,to=nrow(Matdegree1))){
    Matdegree <- rbind(Matdegree,Matdegree1[r,])
    Matrice <- cbind(Matrice,matrix(1,length(Sortie),1))
    Fin <- ncol(Matrice)
    Ind <- which(Matdegree[Fin,]>0)
    if(length(Ind)!=0){
      for(n in seq(1:length(Ind))){
        Mat_puiss <- matrix(0,Nsample,(Matdegree[Fin,Ind[n]]+1))
        for(p in seq(1:(Matdegree[Fin,Ind[n]]+1))){
          Mat_puiss[,p] <- Fact[,Ind[n]]^(p-1)
        }
        Vecteur <- Mat_puiss%*%MatriceCoeff[[paste('Inp',Ind[n])]][(Matdegree[Fin,Ind[n]]+1),1:(Matdegree[Fin,Ind[n]]+1)]
        Matrice[,Fin] <- Matrice[,Fin]*Vecteur/(sqrt(Alpha1[Matdegree[Fin,Ind[n]],Ind[n]]))
      }
      Sigma2P=c(Sigma2P,((sum(Matdegree[Fin,Ind])+length(Ind)-1)*length(Ind)^puiss))
    }
    else{
      print("Error somewhere! Please check Matdegree")
      return()
    }
    Lambda <- 1
    Lambda_prec <- 0
    counter <- 0
    while(max(abs(Lambda_prec-Lambda)/Lambda)>0.0001){
      Lambda_prec <- Lambda
      Cr1 <- solve((t(Matrice)%*%Matrice+Lambda*diag(1/Sigma2P)),t(Matrice)%*%y_std)
      Lambda <- sum((y_std-Matrice%*%Cr1)^2)/Nsample
      counter <- counter+1
      if(counter==100){
        break
      }
    }
    Sigma2e <- Lambda
    DetJ <- 0
    N <- 0
    while((is.infinite(DetJ))|(DetJ==0)){
      #I divide by Nsample^N to avoid DetJ=Inf. This is corrected below in the KIC
      DetJ <- det(t(Matrice)%*%Matrice/((Nsample^N)*Sigma2e)+diag(1/((Nsample^N)*Sigma2P)))
      if(is.infinite(DetJ)){
        N <- N+1
      }
      else if(DetJ==0){
        N <- N-1/20
      }
    }
    #Kashyap IC, as small as possible
    KIC <- Nsample*log(Sigma2e)+N*ncol(Matrice)*log(Nsample)+log(abs(DetJ))+sum(log(Sigma2P))+sum(Cr1^2/Sigma2P)
    if(is.infinite(KIC)){
      KIC <- -Inf
      Result <- Cr1^2
      print(Sigma2e,abs(DetJ))
      break
    }
    else if(KIC<KIC_Prec){
      KIC_Prec <- KIC
      Result <- Cr1^2
      Sigma2e_Prec <- Sigma2e
    }
    else{
      Matrice <- Matrice[,1:(Fin-1)]
      Sigma2P <- Sigma2P[1:(Fin-1)]
      Matdegree <- Matdegree[1:(Fin-1),]
      Cr1 <- solve(t(Matrice)%*%Matrice+Lambda*diag(1/Sigma2P),t(Matrice)%*%y_std)
      Result <- Cr1^2
    }
  }
  Sigma2e <- mean((y_std-Matrice%*%Cr1)^2)
  SPCE=list()
  Result[1] <- 0#Remove the mean value
  SPCE$Cr  <- Cr1
  SPCE$Mat <- Matdegree
  SPCE$Var <- sum(Result)*var(Sortie)
  SPCE$Res <- sum((y_std-Matrice%*%Cr1)^2)/(Nsample*sum(Result))
  SPCE$Muy <- mean(Sortie)
  SPCE$Sigmay <- sd(Sortie)
  SPCE$Cov <- solve(t(Matrice)%*%Matrice/Sigma2e+diag(1/Sigma2P))
  SPCE$Sigma2e <- Sigma2e
  SPCE$Ndraw <- Nsample
  #Test of Normality
  SPCE$Residual <- (y_std-Matrice%*%Cr1)
  return(SPCE)
}
###########################################################
#------------------ Compute_SI ---------------------
###########################################################
#------------------ Compute_SI: Compute the Sensitivity Indices & Main Effects ----------
# [Response] = function(PCE,Type)
# PCE = The identified BSPCE
# Type is string array or the data array used to build the PCE (Type="Generalized")
# Response: Structure that gather the estimated Sobol Indices
Compute_SI<-function(PCE,PDFType=vector())
{
  Nvar   <- ncol(PCE$Mat)
  NCoeff <- nrow(PCE$Mat)
  Degree_max <- max(PCE$Mat)
  DOE <- matrix()
  DOE <- PDFType
  Nsample <- nrow(DOE)
  
  PDFType <- vector()
  EffectAbs <- matrix(0,100,Nvar)
  EffectAbs1 <- matrix(0,100,Nvar)
  X_std <- matrix(0,Nsample,Nvar)
  for(p in seq(1:Nvar)){
    X_std[,p] <- (DOE[,p]-mean(DOE[,p]))/sd(DOE[,p])
    EffectAbs1[,p] <- seq(min(DOE[,p]),to = max(DOE[,p]),by = (max(DOE[,p])-min(DOE[,p]))/99)
    EffectAbs[,p] <- seq(from = min(X_std[,p]),to = max(X_std[,p]),by = (max(X_std[,p])-min(X_std[,p]))/99)
    PDFType[p] <- "Unknown"
  }
  
  Alpha1 <- matrix(0,Degree_max,Nvar)
  MatriceCoeff <- list()
  for(p in seq(1:Nvar)){
    MatriceCoeff[[paste('Inp',p)]] <- matrix()
    MatriceCoeff[[paste('Inp',p)]] <- CoefficientPolynomeqqc_GramSchmidt(X_std[,p],Degree_max)
    for(d in seq(1:Degree_max)){
      Alpha1[d,p] <- 1
    }
  }
  
  Fact_STi <- matrix(0,NCoeff,Nvar)
  Fact_Si  <- matrix(0,NCoeff,Nvar)
  AllIndices <- list()
  
  for(r in seq(from=2,to=NCoeff)){
    Ind <- which(PCE$Mat[r,]>0)
    Subscript <- paste0("S_{", toString(Ind), "}", sep="")#
    if(any(names(AllIndices)==Subscript)){
      AllIndices[[paste0(Subscript)]] <- AllIndices[[paste0(Subscript)]] + PCE$Cr[r]^2/(sum(PCE$Cr[-1]^2)+PCE$Sigma2e)
    }
    else{
      AllIndices[[paste0(Subscript)]] <- PCE$Cr[r]^2/(sum(PCE$Cr[-1]^2)+PCE$Sigma2e)
    }
    if(length(Ind)>0){
      Fact_STi[r,Ind] <- 1
    }
    else{
      print("Error somewhere! Please check PCE$Mat")
      return()
    }
    if(length(Ind)==1){
      Fact_Si[r,Ind] <- 1
    }
  }
  
  #Sensitivity Indices Computation
  Nsample1 <- 1000
  Si_MAP   <- t(Fact_Si)%*%PCE$Cr^2/(sum(PCE$Cr[-1]^2)+PCE$Sigma2e)
  STi_MAP  <- t(Fact_STi)%*%PCE$Cr^2/(sum(PCE$Cr[-1]^2)+PCE$Sigma2e)
  Upper <- chol(PCE$Cov,pivot=FALSE)
  Cr_Sample <- matrix(0,NCoeff,Nsample1)
  for(p in seq(1:NCoeff)){
    Cr_Sample[p,] <- rnorm(Nsample1)
    Cr_Sample[p,] <- Cr_Sample[p,] - mean(Cr_Sample[p,])
  }
  for(k in seq(1:Nsample1)){
    Cr_Sample[,k] <- PCE$Cr+t(Upper)%*%Cr_Sample[,k]#Correlated sample
  }
  Partial_Variance <- Cr_Sample^2 #Partial Variance of each term in the PCE
  Sigma2e=1/rgamma(Nsample1,(PCE$Ndraw+2)/2,scale=2/(PCE$Sigma2e*(PCE$Ndraw))) #Variance of the Gaussian error Gamma((N+2)/2,2/SS(x))
  Si_min <- Si_max <- STi_min <- STi_max <- matrix(0,Nvar,1)
  for(p in seq(1:Nvar)){
    Si_Sample  <- (t(Fact_Si[,p])%*%Partial_Variance)/(colSums(Partial_Variance[-1,])+Sigma2e)
    STi_Sample <- (t(Fact_STi[,p])%*%Partial_Variance)/(colSums(Partial_Variance[-1,])+Sigma2e)
    Si_min[p,1]  <- quantile(Si_Sample,0.025,names=FALSE)
    Si_max[p,1]  <- quantile(Si_Sample,0.975,names=FALSE)
    STi_min[p,1] <- quantile(STi_Sample,0.025,names=FALSE)
    STi_max[p,1] <- quantile(STi_Sample,0.975,names=FALSE)
  }
  Si_Value <- cbind(Si_min,Si_MAP,Si_max)
  STi_Value <- cbind(STi_min,STi_MAP,STi_max)
  
  
  #Main effects
  ypce_min1 <- ypce_max1 <- ypce_map1 <- vector()
  EffectMIN <- EffectMAP <- EffectMAX <- matrix(0,100,Nvar)
  for(par in seq(1:Nvar)){
    Matrice <- matrix(1,100,NCoeff)
    for(r in seq(from=2,to=NCoeff)){
      Ind <- which(PCE$Mat[r,]>0)
      if(length(Ind)==1 && Ind==par){
        Mat_puiss <- matrix(0,100,(PCE$Mat[r,Ind]+1))
        for(p in seq(1:(PCE$Mat[r,Ind]+1))){
          Mat_puiss[,p] <- EffectAbs[,par]^(p-1)
        }
        Vecteur <- Mat_puiss%*%MatriceCoeff[[paste('Inp',Ind)]][(PCE$Mat[r,Ind]+1),1:(PCE$Mat[r,Ind]+1)]
        Matrice[,r] <- Matrice[,r]*Vecteur/sqrt(Alpha1[PCE$Mat[r,Ind],Ind]) #orthonormalized
      }
      else{
        Matrice[,r] <- matrix(0,100,1)
      }
    }
    #PCE Response Calculation
    Effects <- PCE$Sigmay*(Matrice%*%Cr_Sample)+PCE$Muy
    for(Nout in seq(1:100)){
      ypce_min1[Nout]  <- quantile(Effects[Nout,],0.025,names=FALSE)
      ypce_max1[Nout]  <- quantile(Effects[Nout,],0.975,names=FALSE)
    }
    ypce_map1 <- PCE$Sigmay*(Matrice%*%PCE$Cr)+PCE$Muy
    EffectMIN[,par] <- ypce_min1
    EffectMAP[,par] <- ypce_map1
    EffectMAX[,par] <- ypce_max1
  }
  
  return(c(list("Si"=Si_Value,"STi"=STi_Value,"EffectAbs"=EffectAbs1, "EffectMIN"=EffectMIN, "EffectMAP"=EffectMAP, "EffectMAX"=EffectMAX), AllIndices))
}
######################## PCE_Sctructure ###############################
# Create the Structure of the PCE = Degree Matrix
#######################################################################
PCE_Structure<-function(Nvar,Poly_Deg,Poly_Level)
{
  NCoeff <- floor(factorial(Poly_Deg+Nvar)/(factorial(Nvar)*factorial(Poly_Deg)))
  
  MatDegree <- matrix(0,NCoeff,Nvar)
  
  MatDegree[1:(Poly_Deg+1),1] <- seq(from=0,to=Poly_Deg)
  
  ######## Create a Matrix of Degrees with maximal Degree <- Poly_Deg
  cnt <- Poly_Deg+1
  for(p in seq(from=2,to=Nvar)){
    fin<-cnt
    for(r in seq(from=1,to=Poly_Deg)){
      VectDeg <- rowSums(MatDegree[1:fin,])+r
      Index<-which(VectDeg<=Poly_Deg)#Find in Vect_ordre which is lower than Poly_Deg
      for(n in seq(along=Index)){
        cnt <- cnt+1
        MatDegree[cnt,1:(p-1)] <- MatDegree[Index[n],1:(p-1)]
        MatDegree[cnt,p] <- r
      }
    }
  }
  
  ###### Filter those terms of Level of Interactions higher than Poly_evel
  MatOne<-MatDegree/replace(MatDegree,which(MatDegree==0),1)
  Indice<-which(rowSums(MatOne)<=Poly_Level)
  MatDegree<-MatDegree[Indice,]
  
  ###### Re-ordering by Polynomial Degree
  VectDeg<-rowSums(MatDegree)
  VectDeg_Sorted<-sort(VectDeg, method = "quick",decreasing = FALSE, index.return = TRUE)
  MatDegree<-MatDegree[VectDeg_Sorted$ix,]
  
  return(MatDegree)
}
#######################################################################
CoefficientPolynomeqqc_GramSchmidt<-function(X,Poly_Deg)#
{
  if(is.null(ncol(X))){
    Nsample <- length(X)
    Nvar    <- 1
  }else{
    Nsample <- nrow(X)
    Nvar    <- ncol(X)
  }
  
  if(Nvar>1){
    message(sprintf("Warning! Only vectors are accepted.\nSo, variable 1 (1st column) is considered."))
    X_std <- X[,1]
  }else{X_std <- X}#X must be standardized in some way: (X-mean(X))/sd(X)
  
  Coefficients <- matrix(0,Poly_Deg+1,Poly_Deg+1)
  Coefficients[1,1] <- 1
  Matrix_Value<-matrix(1,Nsample,Poly_Deg+1)
  Coeff <- vector()
  for(degree in seq(from=1,to=Poly_Deg,by=1)){
    Matrix_Value[,degree+1]=X^degree
    for(puiss in seq(from=1,to=degree,by=1)){
      Coeff[1]<-t(Matrix_Value[,degree+1])%*%Matrix_Value[,puiss]/Nsample
      Matrix_Value[,degree+1]<-Matrix_Value[,degree+1]-Coeff[1]*Matrix_Value[,puiss]
    }
    Matrix_Value[,degree+1]<-(Matrix_Value[,degree+1]-mean(Matrix_Value[,degree+1]))/sd(Matrix_Value[,degree+1])
    ModelPolynomial  <- lm(formula=Matrix_Value[,degree+1] ~ poly(X_std,degree,raw=TRUE))
    Coefficients[degree+1,1:(degree+1)]<-coefficients(ModelPolynomial)
  }
  return(Coefficients)
}

