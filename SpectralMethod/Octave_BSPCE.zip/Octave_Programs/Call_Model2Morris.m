warning('off')
pkg load statistics
%pkg load gnuplot
struct_levels_to_print(0)
close all
clear all
Here=pwd;
addpath([Here,'\Benchmarks'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;%close all
Nvar=20;
for p=1:Nvar
    Type{p}='Uniform';%'Hermite';%
end
typ1={'xb','oc','vm','*k','^g','dk','hr','hg','<m','xr','xc','xm'};%{'xb','xr','xc','xm','xk','xg','xy','*k','*g','*y'};
typ2={'xb','oc','vm','*k','^g','dk','hr','hg','<m','xr','xc','xm'};%{'ob','or','oc','om','xk','og','oy','sk','sg','sy'};
%h1=figure;hold on
y=[];
%h3=figure;
from=9;
till=1;
Nsample=0;
h = waitbar (0, '0.00%');
for it=1:till
  Nsample1=2^(from+it);
  waitbar (it/till, h, 'Please Wait!');
  for k=Nsample+1:Nsample1% LPTAU Quasi-Random draws
      U(k,:)=LPTAU51(k,Nvar);% x in [0,1] sobolseq16384(k,Nvar);%
  end
 
    X=U(Nsample+1:Nsample1,:);
    y1=Model2Morris(X);y=[y;y1];
    
    [SobolIndices,PCE]=BSPCE4SAFEtoolbox(X,y);
    fprintf('Unexplained amount of variance:  %5.4f\n', PCE.Res)
    
    %Sensitivity Indices with uncertainty
    Si_min(:,it)=SobolIndices.Si(:,1);
    STi_min(:,it)=SobolIndices.STi(:,1);
    Si(:,it)=SobolIndices.Si(:,2);
    STi(:,it)=SobolIndices.STi(:,2);
    Si_max(:,it)=SobolIndices.Si(:,3);
    STi_max(:,it)=SobolIndices.STi(:,3);

    Abscisse(:,it) = (1+it*0.1):(Nvar+it*0.1);
    Nsample=Nsample1;
    Leg{it}=['N=2^{' num2str(it+from) '}'];
end
close(h)
h2=figure;
subplot(2,1,1);hold on
for r=1:till
  errorbar(Abscisse(:,r),Si(:,r),Si(:,r)-Si_min(:,r),Si_max(:,r)-Si(:,r),typ1{r});
end
ylabel('S_i'),
legend(Leg);hold off
subplot(2,1,2);
for r=1:till
  errorbar(Abscisse(:,r),STi(:,r),STi(:,r)-STi_min(:,r),STi_max(:,r)-STi(:,r),typ1{r});hold on
end
ylabel('T_i')
xlabel('Input')
