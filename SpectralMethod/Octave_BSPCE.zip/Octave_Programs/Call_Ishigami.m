warning('off')
pkg load statistics
%pkg load gnuplot
struct_levels_to_print(0)
close all
clear all
Here=pwd;
addpath([Here,'\Benchmarks'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nvar=3;%Number of Model Inputs;
for p=1:Nvar
  Type{p}='Uniform';
end

%Nsample=2^7;it=1;
h = waitbar (0, '0.00%');
for Nsample=4*Nvar+1:2^7
  clear X U
  it = Nsample-4*Nvar;
  waitbar (Nsample/2^7, h, 'Please Wait!');
  for k=1:Nsample% LPTAU Quasi-Random draws
      U(k,:)=LPTAU51(k,Nvar);% x in [0,1] sobolseq16384(k,Nvar);%
  end
  X=(2*U-1)*pi;
  y = Model2Ishigami(X,[5,0.1]);
  
  [SobolIndices,PCE]=BSPCE4SAFEtoolbox(X,y);
  fprintf('Unexplained amount of variance:  %5.4f\n', PCE.Res)

  %Sensitivity Indices with uncertainty
  Si_min(:,it)=SobolIndices.Si(:,1);
  STi_min(:,it)=SobolIndices.STi(:,1);
  Si(:,it)=SobolIndices.Si(:,2);
  STi(:,it)=SobolIndices.STi(:,2);
  Si_max(:,it)=SobolIndices.Si(:,3);
  STi_max(:,it)=SobolIndices.STi(:,3);
end
close(h)
%Plot results
figure
typ={'xb','oc','vm','*k','^g','dk','>k','hg','<m','xr','xc','xm'};%{'xb','xr','xc','xm','xk','xg','xy','*k','*g','*y'};
rep=1;
Leg=[];
for p=1:3
  subplot(2,1,1);hold on;errorbar(4*Nvar+1:2^7,Si(p,:),Si(p,:)-Si_min(p,:),Si_max(p,:)-Si(p,:),typ{p});
  subplot(2,1,2),errorbar(4*Nvar+1:2^7,STi(p,:),STi(p,:)-STi_min(p,:),STi_max(p,:)-STi(p,:),typ{p});hold on
  Leg{p}=['x_' num2str(p)];
end
subplot(2,1,1);
ylabel('First-order Sobol index')
legend(Leg)
subplot(2,1,2);
ylabel('Total-order Sobol index')
xlabel('Sample size')