function [SI,PCE] = BSPCE4SAFEtoolbox(X,y)
%[SI,PCE] = BSPCE(X,y)
%Compute the variance-based sensitivity indices (Sobol' indices) with the Bayesian
%Sparse Polynomial Chaos Expansion (BSPCE) introduced in 
%Shao Q., Younes A., Fahs M. and Mara T.A. (2017),Comput. Methods in Appl. Mech. & Engrg. (318) 474-496.
%with the difference that, from given data, PC bases are built with the Gram-Schmidt method.
%Note that Gram-Schmidt based orthogonal bases might perform poorly in some cases.
%Input: X a Monte Carlo sample of size NsamplexNvar, 
%       y the associated model response vector assumed a continuous random variable
%Output: SI contains the information related to the Sobol' indices
%        PCE contains information related to the identified BSPCE
[Nsample,Nvar]=size(X);
Degre_Init=4;
Level_Init=2;
if Nvar>25
    Degre_Init=2;
    Level_Init=1;
end

for p=1:Nvar
  X_std(:,p)=(X(:,p)-mean(X(:,p)))/std(X(:,p));
end

%Compute the BSPCE
PCE=Compute_BSPCE_MAP(X_std,y,Degre_Init,Level_Init);
%Compute sensitivity indices
SI=Compute_SobolIndices(PCE,X_std);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Matdegree] = PCE_Structure(Nvar,MaxDegree,Level)
%[Matdegree] = PCE_Structure(Nvar,MaxDegree,Level)
%Matdegree is a matrix of integer with Nvar columns
%The integer represent the monomial degre associated with the variable in
%the column
%Nvar represents the number of variables
%Maxdegree is the highest polynomial degree to build
%Level is the highest level of interactios (1,Nvar)

Ordre_max=MaxDegree;%PCE maximal degree
Nbre2coeff = round(factorial(Ordre_max+Nvar)/(factorial(Nvar)*factorial(Ordre_max)));

%I create the degree polynomial matrix
Matdegree = zeros(Nbre2coeff,Nvar);
Matdegree(1:Ordre_max+1,1)= [0:Ordre_max]';
cnt = Ordre_max+1;
for p=2:Nvar
    fin = cnt;
    for r=1:Ordre_max
        Vect_Ordre = sum(Matdegree(1:fin,:),2)+r;
        Ind=find(Vect_Ordre<=Ordre_max);
        for n=1:length(Ind)
            cnt=cnt+1;
            Matdegree(cnt,1:p-1)=Matdegree(Ind(n),1:p-1);
            Matdegree(cnt,p)= r;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Filtering to use if size(Matdegre,1) is too
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% high %%%%%%%%%%%%%%%%%%%%%%%%
MatOne=Matdegree./max(Matdegree,1);
Indice=find(sum(MatOne,2)<=Level);
Matdegree=Matdegree(Indice,:);

%%%%%%%%% I increasingly reorder the degree polynomial matrix by degree %%%%%%%%%%%%%%%%%%%%%%
Vect_Ordre=sum(Matdegree')';
[Vect_Ordre,Ind]=sort(Vect_Ordre);
Matdegree=Matdegree(Ind,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Si,Coeff_stk,Y1] = Main_Effect1(X,Y,M)

for r=1:min(size(Y))
   Y1=Y(:,r);
   for par = 1:size(X,2)
      Entree=X(:,par);
      Coeff = polyfit(Entree,Y1,M);
      Sortie_calc = 0;
      for k=0:M
         Sortie_calc = Sortie_calc + Coeff(k+1)*Entree.^(M-k);
      end
      Si(par,r) = var(Sortie_calc)/var(Y(:,r));
      Coeff_stk.Fact(par).Ai(r,:)=Coeff;
      Y1 = Y1 - Sortie_calc;
   end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [PCE] = Compute_BSPCE_MAP(Fact,y,Degre_Init,Level_Init)

[Nsample,Nvar]=size(Fact);
if nargin==2
    Degre_Init=2;
    Level_Init=2;
elseif nargin==3
    Level_Init=2;
    Nbredinconnu=factorial(Degre_Init+Level_Init)/(factorial(Degre_Init)*factorial(Level_Init));
    while Nbredinconnu<1500
        Level_Init=Level_Init+1;
        Nbredinconnu=factorial(Degre_Init+Level_Init)/(factorial(Degre_Init)*factorial(Level_Init));
    end
end

Matdegre = PCE_Structure(Nvar,Degre_Init,Level_Init);%Create the Matrix of Polynomial Degrees

Display='On';
if strcmp(Display,'On')
    fprintf('The number of terms in the SPCE is: %d\n',size(Matdegre,1))
end

PCE.Mat=Matdegre;%Only usefull for passing the first test (while)
Matdegre=[Matdegre;Matdegre(end,:)];%Only usefull for passing the first test (while)
Degre_max=Degre_Init;%Initial max PCE degree
Level_max=Level_Init;%Initial max PCE level of interactions
Reject=[];
while size(Matdegre,1)~=size(PCE.Mat,1)%Stopping criterion
    if strcmp(Display,'On')
        fprintf('Polynomial Degree:  %d\t Interaction Level:  %d\n', Degre_max,Level_max)
    end
    Info.Step=-1;
    while size(PCE.Mat,1)~=size(Matdegre,1)
        Matdegre=PCE.Mat;
        [PCE,Rejet] = Filtre_matrix_pce(Fact,y,Matdegre,Info);%
        [obs,Ind]=sort(PCE.Cr(2:end).^2,1,'descend');
        PCE.Mat=[PCE.Mat(1,:);PCE.Mat(Ind+1,:)];
        Info.Step=1;
        Reject=[Reject;Rejet];
    end
    
    Index=find(sum(PCE.Mat')>=Degre_max-1);
    if ~isempty(Index)
        Degre_max=Degre_max+2;%Increase the maximal degree of PCE
        for j=1:length(Index)
            Ind=find(PCE.Mat(Index(j),:)>0);
            for jj=1:length(Ind)
                Vect1=PCE.Mat(Index(j),:);
                Vect1(1,Ind(jj))=Vect1(1,Ind(jj))+2;
                Test=1;
                for tt=1:size(PCE.Mat,1)
                    if sum(abs(PCE.Mat(tt,:)-Vect1))==0
                        Test=-1;
                        break;
                    end
                end
                if Test==1
                    PCE.Mat=[PCE.Mat;PCE.Mat(Index(j),:)];
                    PCE.Mat(end,Ind(jj))=PCE.Mat(end,Ind(jj))+2;
                end
            end
        end
    end
    
    MatOne=PCE.Mat./max(PCE.Mat,1);
    Param=find(sum(MatOne)>0);%Relevant Inputs
    Indix=find(sum(MatOne')==Level_max);%Is the Level interactions = current max level?
    if ~isempty(Indix)
        Level_max=min(Nvar,Level_max+1);%Increase the maximal level of interactions
        for j=1:length(Indix)
            Indux=find(PCE.Mat(Indix(j),Param)==0);
            d=Degre_max-sum(PCE.Mat(Indix(j),:));
            for jj=1:d
                for jjj=1:length(Indux)
                    Vect=PCE.Mat(Indix(j),:);
                    Vect(1,Param(Indux(jjj)))=jj;
                    Test=1;
                    for tt=1:size(PCE.Mat,1)
                        if sum(abs(PCE.Mat(tt,:)-Vect))==0
                            Test=-1;
                            break;
                        end
                    end
                    if Test==1
                        PCE.Mat=[PCE.Mat;PCE.Mat(Indix(j),:)];
                        PCE.Mat(end,Param(Indux(jjj)))=jj;
                    end
                end
            end
        end
    end
end
%An ultimate pulishing
Info.Step=-1;%From the 1st step (with re-ordering)
Matdegre=[PCE.Mat;Reject];
while size(PCE.Mat,1)~=size(Matdegre,1)
    Matdegre=PCE.Mat;
    [PCE] = Filtre_matrix_pce(Fact,y,Matdegre,Info);
    Info.Step=1;
    Info.KIC=PCE.KIC;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [MatCoeff] = Coeff_Polynomeqqc_GS(X_std,Degre)
Nsample=size(X_std,1);

if size(X_std,2)>1
    disp('Warning! Only vector is accepted. So, only the first column is considered.')
    X_std=X_std(:,1);
end

if Nsample<2*Degre,
    disp(['Warning! The sample size is too small as compared to the maximal polynomial degree. The polynomial degree has been set to ' num2str(floor(Nsample/2))])
    Degre=floor(Nsample/2);
end

% Gram-Schmidt orthogonisation procedure
MatCoeff = zeros(Degre+1,Degre+1);%
MatCoeff(1,1) = 1;
MatCoeff(2,2) = 1;
XMatrix=X_std;
for n=2:Degre
    Xn=X_std.^n;
    Xn=Xn-mean(Xn);
    for nn=1:(n-1)
        Xn=Xn-mean(Xn.*XMatrix(:,nn))*XMatrix(:,nn);
    end
    Xn_std = (Xn-mean(Xn))/std(Xn);%
    XMatrix=[XMatrix,Xn_std];
    Coeff=polyfit(X_std,Xn_std,n);
    MatCoeff(n+1,1:n+1) = Coeff(end:-1:1);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [SPCE,Rejet] = Filtre_matrix_pce(Fact,Sortie,Matdegre,Info)

[Nsample,Nvar]=size(Fact);
Matdegre1=Matdegre;
Ordre_max=max(sum(Matdegre'));

for p=1:Nvar
    MatriceCoeff(p).Value = Coeff_Polynomeqqc_GS(Fact(:,p),max(Matdegre(:,p)));
    for d=1:Ordre_max
        Alpha1(d,p) = 1;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% STEP 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
y=Sortie;
if Info.Step<=0
    Variance(size(Matdegre,1),size(Sortie,2))=0;
    for r = 2:size(Matdegre,1)
        Matrice=ones(size(Sortie,1),1);
        Ind=find(Matdegre(r,:)>0);
        if ~isempty(Ind)
            for n=1:length(Ind)
                for p = 1:Matdegre(r,Ind(n))+1
                    Mat_puiss(:,p) = Fact(:,Ind(n)).^(p-1);
                end
                Vecteur = Mat_puiss*(MatriceCoeff(Ind(n)).Value(Matdegre(r,Ind(n))+1,1:Matdegre(r,Ind(n))+1)');
                Matrice = Matrice.*Vecteur;
                clear Mat_puiss
            end
        else
            disp('Erreur quelque part : voir Matdegre')
        end
        if exist ('OCTAVE_VERSION', 'builtin')
            Variance(r,1)=(corr(Matrice,y).^2);
        else
            MatCorr=(corrcoef(Matrice,y).^2);
            Variance(r,1)==MatCorr(1,2);
        end
    end
    Matdegre1=Matdegre;
    
    [Variance,Indice]=sort(Variance(2:end),1,'descend');
    Indice=[1;Indice+1];
    Matdegre=Matdegre1(Indice,:);
    
    %%%%%%%%%%%%%%%%%%%%%%%%% STEP 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    y=Sortie;
    Variance(size(Matdegre,1),size(Sortie,2))=0;
    for r = 2:size(Matdegre,1)
        %waitbar(r/size(Matdegre,1),figh)
        Matrice=ones(size(Sortie,1),1);
        Ind=find(Matdegre(r,:)>0);
        if ~isempty(Ind)
            for n=1:length(Ind)
                for p = 1:Matdegre(r,Ind(n))+1
                    Mat_puiss(:,p) = Fact(:,Ind(n)).^(p-1);
                end
                Vecteur = Mat_puiss*(MatriceCoeff(Ind(n)).Value(Matdegre(r,Ind(n))+1,1:Matdegre(r,Ind(n))+1)');
                Matrice = Matrice.*Vecteur;
                clear Mat_puiss
            end
        else
            disp('Erreur quelque part : voir Matdegre')
        end
        y1=y;
        x_std=(Matrice-mean(Matrice))/std(Matrice);
        y_std=(y-mean(y))/std(y);
        Ai=polyfit(x_std,y_std,1);
        Variance(r,1)=(Ai(1).^2)*var(y)/var(Sortie);
        [obs,Coeff,y1]=Main_Effect1(Matrice-mean(Matrice),y-mean(y),1);
        y=y1;
    end
    Matdegre1=Matdegre;
    
    [Variance,Indice]=sort(Variance(2:end),1,'descend');
    Variance=[0;Variance];
    Indice=[1;Indice+1];
    Matdegre1=Matdegre1(Indice,:);
end

%%%%%%%%%%%%%%%%%%%%%%%%% STEP 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
y_std=(Sortie-mean(Sortie))/std(Sortie);
Rejet=[];
Sigma2P=1;
Matdegre=Matdegre1(1,:);
Matrice=ones(size(Sortie,1),1);
KIC_Prec=Inf;
q=2.0;
for r=2:size(Matdegre1,1)
    Matdegre=[Matdegre;Matdegre1(r,:)];
    Matrice=[Matrice,ones(size(Sortie,1),1)];
    Ind=find(Matdegre(end,:)>0);
    if ~isempty(Ind)
        for n=1:length(Ind)
            for p = 1:Matdegre(end,Ind(n))+1
                Mat_puiss(:,p) = Fact(:,Ind(n)).^(p-1);
            end
            Vecteur = Mat_puiss*(MatriceCoeff(Ind(n)).Value(Matdegre(end,Ind(n))+1,1:Matdegre(end,Ind(n))+1)');
            Matrice(:,end) = Matrice(:,end).*Vecteur/(sqrt(Alpha1(Matdegre(end,Ind(n)),Ind(n))));%orthonormalized
            clear Mat_puiss
        end
        Sigma2P=[Sigma2P;(sum(Matdegre(end,Ind))+(length(Ind)-1)*length(Ind)^q)];
    else
        disp('Erreur quelque part : voir Matdegre')%
    end
    Lambda=1;
    Lambda_prec=0;
    counter=0;
    Fac=1.0;Fac_prec=0;
    while ((abs(Lambda_prec-Lambda)./Lambda)>0.0001)&((abs(Fac_prec-Fac)./Fac)>0.001)
        Lambda_prec=Lambda;
        Fac_prec=Fac;
        Cr1=((Matrice')*Matrice+Lambda*diag(1./(Fac*Sigma2P)))\((Matrice')*y_std);
        Lambda = sum((y_std-Matrice*Cr1).^2)/Nsample;
        %Fac=mean(Cr1.^2./Sigma2P);%Discard to stick to the original method
        counter=counter+1;
        if counter==100
            disp("MayDay")
            break;
        end
    end
    
    Sigma2e = Lambda;
    DetJ=Inf;
    N=0;
    while or(isinf(DetJ),DetJ==0)
        DetJ=det((Matrice')*Matrice/(Nsample^N*Sigma2e)+diag(1./(Nsample^N*Fac*Sigma2P)));%I divide by Nsample^N to avoid DetJ=Inf. This is corrected below in the KIC
        if isinf(DetJ)
            N=N+1;
        elseif DetJ==0
            N=N-1/20;
        end
    end
    KIC=Nsample*log(Sigma2e)+N*size(Matrice,2)*log(Nsample)+log(abs(DetJ))+sum(log(Fac*Sigma2P))+sum(Cr1.^2./(Fac*Sigma2P));%Kashyap IC, as small as possible

    if isinf(KIC),KIC=-Inf;Result=Cr1.^2;Sigma2e,abs(DetJ),disp('l�');break;end
    
    if (KIC<KIC_Prec)&(Cr1(end)^2>Cr1(1)^2/10)%%%%%%%%%%%%%%%%%%%%%%
        KIC_Prec=KIC;
        Result=Cr1.^2;
        Sigma2e_Prec=Sigma2e;
    else
        Matrice=Matrice(:,1:end-1);
        Sigma2P=Sigma2P(1:end-1);
        Rejet=[Rejet;Matdegre(end,:)];
        Matdegre=Matdegre(1:end-1,:);
        Cr1=((Matrice')*Matrice+Lambda*diag(1./(Fac*Sigma2P)))\((Matrice')*y_std);%inv((Matrice')*Matrice+Lambda*diag(1./Sigma2P))*(Matrice')*y_std;%Biased estimate
        Result = Cr1.^2;
    end
end
Sigma2e=mean((y_std-Matrice*Cr1).^2);

[obs,Ind]=sort(Result(2:end),'descend');
Ind=[1;Ind+1];

Result(1) = 0;%Remove the mean value
SPCE(1).Cr=Cr1(Ind,1);
SPCE(1).Mat=Matdegre(Ind,:);
SPCE(1).Var=sum(Result)*var(Sortie);
SPCE(1).Res=sum((y_std-Matrice*Cr1).^2)/(Nsample);%
SPCE(1).Muy=mean(Sortie);
SPCE(1).Sigmay=std(Sortie);
SPCE(1).Cov=inv((Matrice(:,Ind)')*Matrice(:,Ind)/Sigma2e+diag(1./(Fac*Sigma2P(Ind,1))));
SPCE(1).Sigma2e=Sigma2e;
SPCE(1).Ndraw=Nsample;
%Test of Normality
SPCE(1).Residual=(y_std-Matrice*Cr1);
SPCE(1).KIC=KIC_Prec;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Response] = Compute_SobolIndices(PCE,DOE)
% [Response] = Compute_SobolIndices(PCE,DOE[optional])
% Compute the Sobol' Indices for the sparse PCE
[Nbredinconnu,Nvar]=size(PCE.Mat);
if nargin==2
    for p=1:Nvar
        DOE(:,p)=(DOE(:,p)-mean(DOE(:,p)))/std(DOE(:,p));
    end
end

Ordre_max=max(sum(PCE.Mat,2));
x=(-1:2/99:1)';
for p=1:Nvar
    MatriceCoeff(p).Value = Coeff_Polynomeqqc_GS(DOE(:,p),max(PCE.Mat(:,p))+1);
    uh(1,p)=(max(DOE(:,p))+min(DOE(:,p)))/2;
    vh(1,p)=(max(DOE(:,p))-min(DOE(:,p)))/2;
    Response.EffectAbs(:,p)=x*vh(p)+uh(p);
end

for d=1:Ordre_max
    for p=1:Nvar
        Alpha1(d,p) = 1/(2*d+1);
    end
end

Fact_STi = zeros(Nbredinconnu,Nvar);
Fact_STi_Shapley = zeros(Nbredinconnu,Nvar);
Fact_Si = zeros(Nbredinconnu,Nvar);
Index=zeros(Nbredinconnu,1);%
Subscript=[];
for r=2:Nbredinconnu
    Ind=find(PCE.Mat(r,:)>0);
    if ~isempty(Ind)
        Fact_STi(r,Ind)=1;
        if length(Ind)==1
            Fact_Si(r,Ind) = 1;
        end
        Fact_STi_Shapley(r,:)=Fact_STi(r,:)/sum(Fact_STi(r,:));
        Format=[];
        for n=1:length(Ind)
            Format=[Format,'%d'];
        end
        II=find(Subscript==str2num(num2str(Ind,Format)));
        if isempty(II)
            Subscript=[Subscript;str2num(num2str(Ind,Format))];
            Subscript2{length(Subscript)}=num2str(Ind(1));
            for n=2:length(Ind)
                Subscript2{length(Subscript)}=[Subscript2{length(Subscript)},'_',num2str(Ind(n))];
            end
            Index(r)=max(Index)+1;
        else
            Index(r)=II(1);
        end
        
    else
        disp('Erreur quelque part : voir PCE.Mat')
    end
end

%Sensitivity Indices Computation
Nsample=1000;
Si_MAP=(Fact_Si')*PCE.Cr.^2/(sum(PCE.Cr(2:end).^2)+PCE.Sigma2e);
STi_MAP=(Fact_STi')*PCE.Cr.^2/(sum(PCE.Cr(2:end).^2)+PCE.Sigma2e);
Shapley_MAP=(Fact_STi_Shapley')*PCE.Cr.^2/(sum(PCE.Cr(2:end).^2)+PCE.Sigma2e);
Sigma2e=1./gamrnd((PCE.Ndraw+2)/2,2/(PCE.Sigma2e*(PCE.Ndraw)),1,Nsample);%Variance of the Gaussian error, Gamma((N+2)/2,2/SS(x))
Cr_Sample=mvnrnd(PCE.Cr,PCE.Cov,Nsample)';%Sample 1000 random draws from the posterior
Partial_Variance=Cr_Sample.^2;%Partial Variance of each term in the PCE
for p=1:Nvar
    Si_Sample(:,p) =[(Fact_Si(:,p)')*Partial_Variance./(sum(Partial_Variance(2:end,:))+Sigma2e)]';
    STi_Sample(:,p)=[(Fact_STi(:,p)')*Partial_Variance./(sum(Partial_Variance(2:end,:))+Sigma2e)]';
    Shapley_Sample(:,p)=[(Fact_STi_Shapley(:,p)')*Partial_Variance./(sum(Partial_Variance(2:end,:))+Sigma2e)]';
    [Si_min(p,1),Si_med(p,1),Si_max(p,1)]=Uncertainty(Si_Sample(:,p),0.05);
    [STi_min(p,1),STi_med(p,1),STi_max(p,1)]=Uncertainty(STi_Sample(:,p),0.05);
    [Shapley_min(p,1),Shapley_med(p,1),Shapley_max(p,1)]=Uncertainty(Shapley_Sample(:,p),0.05);
end
Response.Si=[Si_min,Si_MAP,Si_max];
Response.STi=[STi_min,STi_MAP,STi_max];
Response.Shapley=[Shapley_min,Shapley_MAP,Shapley_max];

%Estimating All the sensitivity indices = Sobol' decomposition
for i=1:length(Subscript)
    II=find(Index==i);
    Sij_Sample=[sum(Partial_Variance(II,:),1)./(sum(Partial_Variance(2:end,:))+Sigma2e)]';
    [Sij_min,Sij_med,Sij_max]=Uncertainty(Sij_Sample,0.05);
    Sij_map=sum(PCE.Cr(II).^2)/(sum(PCE.Cr(2:end).^2)+PCE.Sigma2e);
    eval(['Response.AllIndices.S' Subscript2{i} '= [Sij_min,Sij_map,Sij_max];']);
end

%Main effects
for par=1:Nvar
    Matrice=ones(size(x,1),Nbredinconnu);
    for r=2:Nbredinconnu
        Ind=find(PCE.Mat(r,:)>0);
        if (length(Ind)==1) & (find(Ind==par))
            for p = 1:PCE.Mat(r,Ind)+1
                Mat_puiss(:,p) = Response.EffectAbs(:,par).^(p-1);
            end
            Vecteur = Mat_puiss*(MatriceCoeff(Ind).Value(PCE.Mat(r,Ind)+1,1:PCE.Mat(r,Ind)+1)');
            Matrice(:,r) = Matrice(:,r).*Vecteur/sqrt(Alpha1(PCE.Mat(r,Ind),Ind));%orthonormalized
            clear Mat_puiss
        else
            Matrice(:,r) = zeros(size(x,1),1);
        end
    end
    %PCE Response Calculation
    for k=1:Nsample
        Effects(:,k)= PCE.Sigmay*(Matrice*Cr_Sample(:,k))+PCE.Muy;
    end
    clear ypce_min ypce_max
    for Nout=1:size(Effects,1)
        [ypce_min(Nout,1),ypce_med(Nout,1),ypce_max(Nout,1)]=Uncertainty(Effects(Nout,:)',0.05);
    end
    ypce_map=PCE.Sigmay*(Matrice*PCE.Cr)+PCE.Muy;
    Response.EffectMIN(:,par) = ypce_min;
    Response.EffectMAP(:,par) = ypce_map;
    Response.EffectMAX(:,par) = ypce_max;
end
%%%%%%%%%%%%%%%%%%%%%%%%%Uncertainty%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute Uncertainty range
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Val_min,Val_moy,Val_max] = Uncertainty(y,percent)

for k=1:size(y,2)
    if min(y(:,k))==max(y(:,k))
        Val_moy(1,k)=y(1,k);
        Val_min(1,k)=y(1,k);
        Val_max(1,k)=y(1,k);
        
    else
        F=[1/size(y,1):(1-2/size(y,1))/(size(y,1)-1):1-1/size(y,1)]';
        ys=sort(y(:,k));
        Val_moy(1,k) = mean(y);%interp1(F,ys,0.5);
        Val_min(1,k) = interp1(F,ys,percent/2);
        Val_max(1,k) = interp1(F,ys,1-percent/2);
    end
end
if nargout<3
    figure;plot(Val_moy,'*')
    hold on;plot(Val_min,'--r')
    plot(Val_max,'--r')
end