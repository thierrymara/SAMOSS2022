if exist ('OCTAVE_VERSION', 'builtin')
    warning('off')
    pkg load statistics
    %pkg load gnuplot
    struct_levels_to_print(0)
end
close all
clear all
Here=pwd;
addpath([Here,'\Benchmarks'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nvar=8;%Number of Model Inputs;
for p=1:Nvar
    Type{p}='Uniform';%'Gaussian';%
end
PDF.Coeff=[0.10,0.016,0.0;7.71,1,0.0;63070,100000,115600;6.95,0.0167,0.0;63,116,0.0;6.6,0.033,0.0;1120,1680,0.0;9855,12045,0.0];
PDF.Type={'Normal';'LogNormal';'Triangular';'LogNormal';'Uniform';'LogNormal';'Uniform';'Uniform'};

Nsample=2^7;

for k=1:Nsample% LPTAU Quasi-Random draws
    U(k,:)=LPTAU51(k,Nvar);% x in [0,1] sobolseq16384(k,Nvar);%
end

%Transformation
X(:,1)=sqrt(2)*erfinv(2*U(:,1)-1)*PDF.Coeff(1,2)+PDF.Coeff(1,1);%Normal
%
X(:,2)=exp(sqrt(2)*erfinv(2*U(:,2)-1)*PDF.Coeff(2,2)+PDF.Coeff(2,1));%LogNormal
%
Ind1=find(U(:,3)<(PDF.Coeff(3,2)-PDF.Coeff(3,1))/(PDF.Coeff(3,3)-PDF.Coeff(3,1)));Ind2=find(U(:,3)>=(PDF.Coeff(3,2)-PDF.Coeff(3,1))/(PDF.Coeff(3,3)-PDF.Coeff(3,1)));
X(:,3)=zeros(Nsample,1);
X(Ind1,3)=PDF.Coeff(3,1)+sqrt(U(Ind1,3)*(PDF.Coeff(3,2)-PDF.Coeff(3,1))*(PDF.Coeff(3,3)-PDF.Coeff(3,1)));
X(Ind2,3)=PDF.Coeff(3,3)-sqrt((PDF.Coeff(3,3)-PDF.Coeff(3,2))*(1-U(Ind2,3))*(PDF.Coeff(3,3)-PDF.Coeff(3,1)));%Triangle
%
X(:,4)=exp(sqrt(2)*erfinv(2*U(:,4)-1)*PDF.Coeff(4,2)+PDF.Coeff(4,1));%LogNormal
%
X(:,5)=U(:,5)*(PDF.Coeff(5,2)-PDF.Coeff(5,1))+PDF.Coeff(5,1);%Uniform
%
X(:,6)=exp(sqrt(2)*erfinv(2*U(:,6)-1)*PDF.Coeff(6,2)+PDF.Coeff(6,1));%LogNormal
%
X(:,7)=U(:,7)*(PDF.Coeff(7,2)-PDF.Coeff(7,1))+PDF.Coeff(7,1);%Uniform
%
X(:,8)=U(:,8)*(PDF.Coeff(8,2)-PDF.Coeff(8,1))+PDF.Coeff(8,1);%Uniform

for k=1:Nsample
    y(k,1)=borehole(X(k,:));
end

[SA,PCE]=BSPCE4SAFEtoolbox(X,y);
fprintf('Unexplained amount of variance:  %5.4f\n', PCE.Res)

%Plot results
figure
typ1={'xb','oc','vm','*k','^g','dk','>k','hg','<m','xr','xc','xm'};
rep=1;
subplot(2,1,1);errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.Si(:,2),SA.Si(:,2)-SA.Si(:,1),SA.Si(:,3)-SA.Si(:,2),typ1{rep});
ylabel('First-order Sobol index')
subplot(2,1,2),errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.STi(:,2),SA.STi(:,2)-SA.STi(:,1),SA.STi(:,3)-SA.STi(:,2),typ1{rep});
ylabel('Total-order Sobol index')
xlabel('Input Number')