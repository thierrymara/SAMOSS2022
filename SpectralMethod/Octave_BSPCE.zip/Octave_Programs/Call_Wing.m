warning('off')
pkg load statistics
%pkg load gnuplot
struct_levels_to_print(0)
close all
clear all
Here=pwd;
addpath([Here,'\Benchmarks'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nvar=10;#Number of Model Inputs;
PDF.Coeff=[150,200,0.0;220,300,0;6,10,0.0;0,2,0.0;2,3,16;-0.7,0,0.0;0.08,0.18,0.0;4.25,0.6,0;1700,2000,2500;0.025,20,0.08];
PDF.Type={'Uniform';'Uniform';'Discrete';'Laplace';'Gamma';'LogUniform';'Uniform';'Normal';'Triangular';'Exponential'};

Nsample=2^10;

for k=1:Nsample# LPTAU Quasi-Random draws
    U(k,:)=LPTAU51(k,Nvar);# x in [0,1] sobolseq16384(k,Nvar);#
end

#Transformation
X(:,1)=U(:,1)*(PDF.Coeff(1,2)-PDF.Coeff(1,1))+PDF.Coeff(1,1);#Uniform

X(:,2)=U(:,2)*(PDF.Coeff(2,2)-PDF.Coeff(2,1))+PDF.Coeff(2,1);#Uniform

X(:,3)=floor(U(:,3)*(PDF.Coeff(3,2)-PDF.Coeff(3,1)+1))+PDF.Coeff(3,1);#Discrete Uniform

X(:,4)=zeros(Nsample,1);
Ind1=find(U(:,4)<0.5);Ind2=find(U(:,4)>=0.5);
X(Ind1,4)=PDF.Coeff(4,1)+PDF.Coeff(4,2)*log(2*U(Ind1,4));
X(Ind2,4)=PDF.Coeff(4,1)-PDF.Coeff(4,2)*log(2*(1-U(Ind2,4)));#Laplace

X(:,5)=PDF.Coeff(5,3)+gaminv(U(:,5),PDF.Coeff(5,1),PDF.Coeff(5,2));#Gamma

X(:,6)=exp(U(:,6)*(PDF.Coeff(6,2)-PDF.Coeff(6,1))+PDF.Coeff(6,1));#LogUnif

X(:,7)=U(:,7)*(PDF.Coeff(7,2)-PDF.Coeff(7,1))+PDF.Coeff(7,1);#Uniform

X(:,8)=sqrt(2)*erfinv(2*U(:,8)-1)*PDF.Coeff(8,2)+PDF.Coeff(8,1);#Normal

Ind1=find(U(:,9)<(PDF.Coeff(9,2)-PDF.Coeff(9,1))/(PDF.Coeff(9,3)-PDF.Coeff(9,1)));Ind2=find(U(:,9)>=(PDF.Coeff(9,2)-PDF.Coeff(9,1))/(PDF.Coeff(9,3)-PDF.Coeff(9,1)));
X(:,9)=zeros(Nsample,1);
X(Ind1,9)=PDF.Coeff(9,1)+sqrt(U(Ind1,9)*(PDF.Coeff(9,2)-PDF.Coeff(9,1))*(PDF.Coeff(9,3)-PDF.Coeff(9,1)));
X(Ind2,9)=PDF.Coeff(9,3)-sqrt((PDF.Coeff(9,3)-PDF.Coeff(9,2))*(1-U(Ind2,9))*(PDF.Coeff(9,3)-PDF.Coeff(9,1)));#Triangle
%
X(:,10)=-log(exp(-PDF.Coeff(10,2)*PDF.Coeff(10,1))-U(:,10)*(exp(-PDF.Coeff(10,2)*PDF.Coeff(10,1))-exp(-PDF.Coeff(10,2)*PDF.Coeff(10,3))))/PDF.Coeff(10,2);#Uniform

for k=1:Nsample
    y(k,1)=wingweight(X(k,:));
end

[SA,PCE]=BSPCE4SAFEtoolbox(X,y);
fprintf('Unexplained amount of variance:  %5.4f\n', PCE.Res)

#Plot results
figure
typ1={'xb','oc','vm','*k','^g','dk','>k','hg','<m','xr','xc','xm'};
rep=1;
subplot(2,1,1);errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.Si(:,2),SA.Si(:,2)-SA.Si(:,1),SA.Si(:,3)-SA.Si(:,2),typ1{rep});
ylabel('First-order Sobol index')
subplot(2,1,2),errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.STi(:,2),SA.STi(:,2)-SA.STi(:,1),SA.STi(:,3)-SA.STi(:,2),typ1{rep});
ylabel('Total-order Sobol index')
xlabel('Input Number')