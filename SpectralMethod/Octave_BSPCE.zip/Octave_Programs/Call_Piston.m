warning('off')
pkg load statistics
%pkg load gnuplot
struct_levels_to_print(0)
close all
clear all
Here=pwd;
addpath([Here,'\Benchmarks'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nvar=7;%Number of Model Inputs;
for p=1:Nvar
    Type{p}='Uniform';%'Gaussian';%
end
PDF.Coeff=[30,60,0.0;0.0125,0.0025,0;0.006,1/1500,0.0;6.9,8.5,0.0;9e+4,10e+4,11e+4;290,296,0.0;340,360,0.0];
PDF.Type={'Uniform';'Normal';'Laplace';'LogUniform';'Triangular';'Uniform';'Uniform'};

Nsample=2^10;

for k=1:Nsample% LPTAU Quasi-Random draws
    U(k,:)=LPTAU51(k,Nvar);% x in [0,1] sobolseq16384(k,Nvar);%
end

%Transformation
X(:,1)=U(:,1)*(PDF.Coeff(1,2)-PDF.Coeff(1,1))+PDF.Coeff(1,1);%Uniform
%
X(:,2)=sqrt(2)*erfinv(2*U(:,2)-1)*PDF.Coeff(2,2)+PDF.Coeff(2,1);%Normal
%
X(:,3)=zeros(Nsample,1);
Ind1=find(U(:,3)<0.5);Ind2=find(U(:,3)>=0.5);
X(Ind1,3)=PDF.Coeff(3,1)+PDF.Coeff(3,2)*log(2*U(Ind1,3));
X(Ind2,3)=PDF.Coeff(3,1)-PDF.Coeff(3,2)*log(2*(1-U(Ind2,3)));%Laplace
%
X(:,4)=exp(U(:,4)*(PDF.Coeff(4,2)-PDF.Coeff(4,1))+PDF.Coeff(4,1));%LogUnif
%
Ind1=find(U(:,5)<(PDF.Coeff(5,2)-PDF.Coeff(5,1))/(PDF.Coeff(5,3)-PDF.Coeff(5,1)));Ind2=find(U(:,5)>=(PDF.Coeff(5,2)-PDF.Coeff(5,1))/(PDF.Coeff(5,3)-PDF.Coeff(5,1)));
X(:,5)=zeros(Nsample,1);
X(Ind1,5)=PDF.Coeff(5,1)+sqrt(U(Ind1,5)*(PDF.Coeff(5,2)-PDF.Coeff(5,1))*(PDF.Coeff(5,3)-PDF.Coeff(5,1)));
X(Ind2,5)=PDF.Coeff(5,3)-sqrt((PDF.Coeff(5,3)-PDF.Coeff(5,2))*(1-U(Ind2,5))*(PDF.Coeff(5,3)-PDF.Coeff(5,1)));%Triangle
%
X(:,6)=U(:,6)*(PDF.Coeff(6,2)-PDF.Coeff(6,1))+PDF.Coeff(6,1);%Uniform
%
X(:,7)=U(:,7)*(PDF.Coeff(7,2)-PDF.Coeff(7,1))+PDF.Coeff(7,1);%Uniform

for k=1:Nsample
    y(k,1)=piston(X(k,:));
end

[SA,PCE]=BSPCE4SAFEtoolbox(X,y);
fprintf('Unexplained amount of variance:  %5.4f\n', PCE.Res)

#Plot results
figure
typ1={'xb','oc','vm','*k','^g','dk','>k','hg','<m','xr','xc','xm'};
rep=1;
subplot(2,1,1);errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.Si(:,2),SA.Si(:,2)-SA.Si(:,1),SA.Si(:,3)-SA.Si(:,2),typ1{rep});
ylabel('First-order Sobol index')
subplot(2,1,2),errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.STi(:,2),SA.STi(:,2)-SA.STi(:,1),SA.STi(:,3)-SA.STi(:,2),typ1{rep});
ylabel('Total-order Sobol index')
xlabel('Input Number')