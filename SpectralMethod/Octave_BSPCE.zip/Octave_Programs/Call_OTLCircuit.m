warning('off')
pkg load statistics
%pkg load gnuplot
struct_levels_to_print(0)
close all
clear all
Here=pwd;
addpath([Here,'\Benchmarks'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nvar=6;%Number of Model Inputs;
for p=1:Nvar
    Type{p}='Uniform';%'Gaussian';%
end
PDF.Coeff=[50,150;25,70;0.5,3;1.2,2.5;0.25,1.2;50,300];%[100,33/2,0;25,70,0;3,1/3,0.5;0.18,0.92,0;-0.58,0.27,0;50,100,300];
PDF.Type={'Normal';'Uniform';'Gamma';'LogUniform';'LogNormal';'Triangular'};

Nsample=2^10;

for k=1:Nsample% LPTAU Quasi-Random draws
    U(k,:)=LPTAU51(k,Nvar);% x in [0,1] sobolseq16384(k,Nvar);%
end

%Transformation
X(:,1)=U(:,1)*(PDF.Coeff(1,2)-PDF.Coeff(1,1))+PDF.Coeff(1,1);%Uniform sqrt(2)*erfinv(2*U(:,1)-1)*PDF.Coeff(1,2)+PDF.Coeff(1,1);%Normal
X(:,2)=U(:,2)*(PDF.Coeff(2,2)-PDF.Coeff(2,1))+PDF.Coeff(2,1);%Uniform
X(:,3)=U(:,3)*(PDF.Coeff(3,2)-PDF.Coeff(3,1))+PDF.Coeff(3,1);%Uniform PDF.Coeff(3,3)+gaminv(U(:,3),PDF.Coeff(3,1),PDF.Coeff(3,2));%Gamma
%
X(:,4)=U(:,4)*(PDF.Coeff(4,2)-PDF.Coeff(4,1))+PDF.Coeff(4,1);%Uniform exp(U(:,4)*(PDF.Coeff(4,2)-PDF.Coeff(4,1))+PDF.Coeff(4,1));%LogUniform
X(:,5)=U(:,5)*(PDF.Coeff(5,2)-PDF.Coeff(5,1))+PDF.Coeff(5,1);%Uniform exp(sqrt(2)*erfinv(2*U(:,5)-1)*PDF.Coeff(5,2)+PDF.Coeff(5,1));%LogNormal
%
X(:,6)=U(:,6)*(PDF.Coeff(6,2)-PDF.Coeff(6,1))+PDF.Coeff(6,1);%Uniform zeros(Nsample,1);



for k=1:Nsample
    y(k,1)=otlcircuit(X(k,:));
end

[SA,PCE]=BSPCE4SAFEtoolbox(X,y);
fprintf('Unexplained amount of variance:  %5.4f\n', PCE.Res)

#Plot results
figure
typ1={'xb','oc','vm','*k','^g','dk','>k','hg','<m','xr','xc','xm'};
rep=1;
subplot(2,1,1);errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.Si(:,2),SA.Si(:,2)-SA.Si(:,1),SA.Si(:,3)-SA.Si(:,2),typ1{rep});
ylabel('First-order Sobol index')
subplot(2,1,2),errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.STi(:,2),SA.STi(:,2)-SA.STi(:,1),SA.STi(:,3)-SA.STi(:,2),typ1{rep});
ylabel('Total-order Sobol index')
xlabel('Input Number')