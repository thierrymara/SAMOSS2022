function [Y,Si,STi,D] = gofSobol(X,A)
%Fonction de Sobol : [Y,Si,STi] = f(X,A)
% X est une matrice Nxp o� N est le nbre de simulation,
% p le nombre de param�tre,
% A est un vecteur ayant p �l�ments, ce sont les coefficients
% associ�s au diff�rents facteurs Xi, + A(i)>=0 petit, + Xi influent.
% Y est un vecteur de taille N, contenant les r�sultts de simulations,
% Si est un vecteur de taille p, Si(h) = effet principal de Xh,
% STi est un vecteur de taille p, STi(h) = effet total de Xh.

[N,p1] = size(X);
p = length(A);
if p<=p1
else
   errordlg('Le nombre de colonnes de X doit �tre �gal au nombre d''�l�ment dans A');
   return
end

% Calcul des indices de sensibilit� du 1er ordre
beta = ((1 + A).^(-2))./3;
D = prod((1 + beta)) - 1;
Si = beta;

cmpt=0;
cnt=0;
for k=1:length(Si)
   for kk=k+1:length(Si)
      cnt=cnt+1;
      Sij(cnt)=Si(k)*Si(kk);
      STij1 = [Si(k),Si(kk),Si(k)*Si(kk)];
      for kkk=1:min(p,10)
         if kkk~=k & kkk~=kk
             cmpt=cmpt+1;
            STij1 = [STij1 STij1*Si(kkk)];
            Sijk(cmpt) = Si(k)*Si(kk)*Si(kkk);
         end
      end
      STij(cnt) = sum(STij1);
   end
end


% Calcul des indices de sensibilit� totaux
for i = 1:p
   STi(i) = Si(i);
   ST1 = Si(i);
   for j = 1:min(p,10)
      if i~=j
         ST1 = [ST1 ST1*Si(j)];
      end
   end
   STi(i) = sum(ST1);
end

% Finalement les indices sont :
Si = Si./D;
STi = STi./D;
%STij = STij./D;
%Sij=Sij./D;
%Sijk=Sijk./D;

% Evaluation de la fonction de Sobol
for i = 1:N
   Y(i,1)=1.;
   for j=1:p
      Y(i,1)=Y(i,1).*g(X(i,j),A(j));
   end
end

% for i = 1:N
%     for j=1:p
%         [yi,dyi]=g(X(i,j),A(j));
%         DY(i,j)=dyi;
%         for jj=1:p
%             if jj~=j
%                 DY(i,j)=DY(i,j).*g(X(i,jj),A(jj));
%             end
%         end
%     end
% end


function [yi,dyi]=g(x,a)
yi=(abs(4*x-2)+a)/(1+a);
dyi=4*sign(4*x-2)/(1+a);
