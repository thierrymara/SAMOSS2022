function y = ModelOfMorris(Fact)

Nvar=size(Fact,2);

load MorrisCoeff.mat

y=0;
%Coeff=[];
cnt=0;
for p=1:Nvar
    %Coeff=[Coeff,randn(1,1)];
    if (p==3)|(p==5)|(p==7)
        X(:,p)=2*(1.1*Fact(:,p)./(Fact(:,p)+0.1)-0.5);
    else
        X(:,p)=2*(Fact(:,p)-0.5);
    end
%     if p<=10
%         Coeff(end)=+20;
%     end
    cnt=cnt+1;
    y=y+Coeff(cnt)*X(:,p);
end

for p=1:Nvar
    for pp=p+1:Nvar
%         Coeff=[Coeff,randn(1,1)];
%         if p<=6 & pp<=6
%             Coeff(end)=-15;
%         end
        cnt=cnt+1;
        y=y+Coeff(cnt)*X(:,p).*X(:,pp);
    end
end

for p=1:Nvar
    for pp=p+1:Nvar
        for ppp=pp+1:Nvar
%             Coeff=[Coeff,0];
%             if p<=5 & pp<=5 & ppp<=5
%                 Coeff(end)=-10;
%             end
            cnt=cnt+1;
            y=y+Coeff(cnt)*X(:,p).*X(:,pp).*X(:,ppp);
        end
    end
end

for p=1:Nvar
    for pp=p+1:Nvar
        for ppp=pp+1:Nvar
            for pppp=ppp+1:Nvar
                %Coeff=[Coeff,0];
                %if p<=4 & pp<=4 & ppp<=4 & pppp<=4
                %    Coeff(end)=+5;
                %end
                cnt=cnt+1;
                y=y+Coeff(cnt)*X(:,p).*X(:,pp).*X(:,ppp).*X(:,pppp);
            end
        end
    end
end

%save Coeff.mat Coeff
