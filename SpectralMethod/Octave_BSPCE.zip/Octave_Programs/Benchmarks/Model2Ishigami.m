function [Y,Si,STi,D] = Ishigami(X,A)
%Fonction de Ishigami : [Y,Si,STi] = f(X,A) = sinX_1 + a*sin�X_2 + b*(X_3)^4*sinX_1
%X_i = U(-pi,+pi)
% X est une matrice Nxp o� N est le nbre de simulation,
% p le nombre de param�tre,
% A est un vecteur ayant p �l�ments, ce sont les coefficients
% associ�s au diff�rents facteurs Xi, + A(i)>=0 petit, + Xi influent.
% Y est un vecteur de taille N, contenant les r�sultts de simulations,
% Si est un vecteur de taille p, Si(h) = effet principal de Xh,
% STi est un vecteur de taille p, STi(h) = effet total de Xh.

[N,p1] = size(X);
p = length(A);
if p<=1
   errordlg('Le nombre d''�l�ment dans A = 2');
   return
end

% Calcul des indices de sensibilit� du 1er ordre
D = (A(1)^2)/8 + (A(2)*pi^4)/5 + (A(2)^2*pi^8)/18 + 0.5;
D1 = (A(2)*pi^4)/5 + (A(2)^2*pi^8)/50 + 0.5;
D2 = (A(1)^2)/8;
D3 = 0;D12=0;D23=0;
D13 = 8*A(2)^2*pi^8/225;
D123=0;

% Finalement les indices sont :
Si = [D1/D,D2/D,D3/D];
STi = [(D1+D13)/D,(D2)/D,(D3+D13)/D];

% Evaluation de la fonction de Ishigami
Y(:,1)= sin(X(:,1)) + A(1)*(sin(X(:,2)).^2)+A(2)*(X(:,3).^4).*sin(X(:,1));

