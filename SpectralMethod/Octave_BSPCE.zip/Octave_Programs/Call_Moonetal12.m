warning('off')
pkg load statistics
%pkg load gnuplot
struct_levels_to_print(0)
close all
clear all
Here=pwd;
addpath([Here,'\Benchmarks'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Nvar=8+10+6+7;%Borehole+Wing+OTL+Piston
Nsample=2^7;
PDF.Coeff=[0.10, 0.016;7.71, 1.0;63070, 115600;990, 1110;...
    63.1, 116;700, 820;1120, 1680;9855, 12045;150,200;220,300;6,10;0,2;16,45;...
    0.5,1;0.08,0.18;2.5,6;1700,2500;0.025,0.08;50,150;25,70;0.5,3;...
    1.2,2.5;0.25,1.2;50,300;30,60;0.005,0.020;0.002,0.010;1000,5000;...
    90000,110000;290,296;340,360];

%Marginal PDFs
for p=1:Nvar
    Type{p}='Uniform';
    PDF.Type{p}='Uniform';
end
%LPtau sampling
for k=1:Nsample% LPTAU Quasi-Random draws
    U(k,:)=LPTAU51(k,Nvar);% x in [0,1]
end
%scaling of the input values
PDF.Type{1}='Normal';
Inp(:,1)=PDF.Coeff(1,1)+sqrt(2)*erfinv(2*U(:,1)-1)*PDF.Coeff(1,2);%Normal
PDF.Type{2}='LogNormal';
Inp(:,2)=exp(PDF.Coeff(2,1)+sqrt(2*PDF.Coeff(2,2))*erfinv(2*U(:,2)-1));%LogNormal
for p=3:Nvar
    Inp(:,p)=PDF.Coeff(p,1)+(PDF.Coeff(p,2)-PDF.Coeff(p,1))*U(:,p);%Uniform
end
%
PDF.Type{12}='Laplace';
Inp(:,12)=zeros(Nsample,1);
Ind1=find(U(:,12)<0.5);Ind2=find(U(:,12)>=0.5);
Inp(Ind1,12)=PDF.Coeff(12,1)+PDF.Coeff(12,2)*log(2*U(Ind1,12));
Inp(Ind2,12)=PDF.Coeff(12,1)-PDF.Coeff(12,2)*log(2*(1-U(Ind2,12)));%Laplace
%Modelruns
for k=1:Nsample
    Out(k,1)=moonetal12(Inp(k,:));
end

[SA,PCE]=BSPCE4SAFEtoolbox(Inp,Out);
fprintf('Unexplained amount of variance:  %5.4f\n', PCE.Res)

#Plot results
figure
typ1={'xb','oc','vm','*k','^g','dk','>k','hg','<m','xr','xc','xm'};
rep=1;
subplot(2,1,1);errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.Si(:,2),SA.Si(:,2)-SA.Si(:,1),SA.Si(:,3)-SA.Si(:,2),typ1{rep});
ylabel('First-order Sobol index')
subplot(2,1,2),errorbar((1+rep*0.1):(Nvar+rep*0.1),SA.STi(:,2),SA.STi(:,2)-SA.STi(:,1),SA.STi(:,3)-SA.STi(:,2),typ1{rep});
ylabel('Total-order Sobol index')
xlabel('Input Number')