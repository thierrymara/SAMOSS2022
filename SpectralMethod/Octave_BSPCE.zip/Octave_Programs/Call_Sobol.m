warning('off')
pkg load statistics
%pkg load gnuplot
struct_levels_to_print(0)
close all
clear all
Here=pwd;
addpath([Here,'\Benchmarks'])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Coeff=[99,0,9,0,99,4.5,1,0,99,99,99,99,99,99,99,99,99,99,99,99,99,99*ones(1,10)];;
Nvar=length(Coeff);%Number of Model Inputs;
for p=1:Nvar
  Type{p}='Uniform';
end

h = waitbar (0, '0.00%');
for Nsample=2*Nvar+1:2^7
  clear X U
  it = Nsample-2*Nvar;
  waitbar (Nsample/2^7, h, 'Please Wait!');
  for k=1:Nsample% LPTAU Quasi-Random draws
      U(k,:)=LPTAU51(k,Nvar);% x in [0,1] sobolseq16384(k,Nvar);%
  end
  X=U;
  y = Model2Sobol(X,Coeff);
  
  [SobolIndices,PCE]=BSPCE4SAFEtoolbox(X,y);
  fprintf('Unexplained amount of variance:  %5.4f\n', PCE.Res)

  %Sensitivity Indices with uncertainty
  Si_min(:,it)=SobolIndices.Si(:,1);
  STi_min(:,it)=SobolIndices.STi(:,1);
  Si(:,it)=SobolIndices.Si(:,2);
  STi(:,it)=SobolIndices.STi(:,2);
  Si_max(:,it)=SobolIndices.Si(:,3);
  STi_max(:,it)=SobolIndices.STi(:,3);
end
close(h)
%Plot results
figure
typ={'xb','oc','vm','*k','^g','dk','>k','hg','<m','xr','xc','xm'};%{'xb','xr','xc','xm','xk','xg','xy','*k','*g','*y'};
rep=1;
Leg=[];
for p=1:Nvar
  subplot(2,1,1);hold on;errorbar(2*Nvar+1:2^7,Si(p,:),Si(p,:)-Si_min(p,:),Si_max(p,:)-Si(p,:),typ{p});
  subplot(2,1,2),errorbar(2*Nvar+1:2^7,STi(p,:),STi(p,:)-STi_min(p,:),STi_max(p,:)-STi(p,:),typ{p});hold on
  Leg{p}=['x_{' num2str(p) '}'];
end
subplot(2,1,1);
ylabel('First-order Sobol index')
legend(Leg, "location", "NorthWest")
subplot(2,1,2);
ylabel('Total-order Sobol index')
xlabel('Sample size')